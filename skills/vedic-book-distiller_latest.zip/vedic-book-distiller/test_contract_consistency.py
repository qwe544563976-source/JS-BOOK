import contextlib
import importlib.util
import io
import json
import re
import tempfile
import unittest
from collections import Counter
from pathlib import Path

from scripts.validate import (
    CARD_KIND,
    CARD_REQUIRED,
    CHAPTER_STATUS,
    COVERAGE_REQUIRED,
    COVERAGE_STATUS,
    MANIFEST_REQUIRED,
    PARENT_KIND,
    PARENT_REQUIRED,
    SLOKA_STATUS,
    TEXT_ROLE,
)
from scripts.pipeline import (
    build,
    build_map,
    case_study_config_gaps,
    case_study_for_heading_path,
    detect_has_sloka,
    discard_misdrop_report,
    first_sloka,
    heading_paths_for_rows,
    normalize_chapter_title_sequence,
    page_furniture_source_ids,
    package,
    scan_chapters,
    sentence_chunks,
    source_units,
    running_header_source_ids,
)
from scripts.check_gate import CONTRACT_VERSION, evaluate as evaluate_quality_gate, is_high_confidence_mush
from scripts.assemble import _discard_reason
from scripts.validate import validate


ROOT = Path(__file__).resolve().parent
CONTRACT = ROOT / "references" / "PACKAGE_CONTRACT.md"
PEER_CONTRACT = ROOT.parent / "vedic-evidence-retrieval" / "reference" / "PACKAGE_CONTRACT.md"
PEER_VALIDATOR = ROOT.parent / "vedic-evidence-retrieval" / "scripts" / "validate_package.py"


def load_peer_validator():
    spec = importlib.util.spec_from_file_location("retrieval_validate_package", PEER_VALIDATOR)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def codes(text: str) -> tuple[str, ...]:
    return tuple(re.findall(r"`([^`]+)`", text))


def section(text: str, number: int) -> str:
    match = re.search(rf"(?ms)^## {number}\..*?(?=^## |\Z)", text)
    if not match:
        raise AssertionError(f"契约缺少第 {number} 节")
    return match.group(0)


def contract_values(path: Path) -> dict[str, tuple[str, ...]]:
    text = path.read_text(encoding="utf-8")
    manifest = section(text, 2)
    manifest_fields = tuple(
        match.group(1) for match in re.finditer(r"(?m)^- `([^`]+)`$", manifest)
    )
    parent = section(text, 3)
    card = section(text, 4)
    state = section(text, 5)
    coverage = section(text, 6)
    parent_fields = codes(re.search(r"每行必须包含：\s*\n\s*([^\n]+)", parent).group(1))
    card_fields = codes(re.search(r"每行必须包含：\s*\n\s*([^\n]+)", card).group(1))
    coverage_fields = codes(re.search(r"每行必须包含 ([^\n]+)", coverage).group(1))
    parent_kind = codes(re.search(r"`kind` 只能是 ([^\n]+)", parent).group(1))
    card_kind = codes(re.search(r"`kind` 只能是 ([^\n]+)", card).group(1))
    text_roles = codes(re.search(r"`text_role` 只能是 ([^\n]+)", card).group(1))
    chapter_status = codes(re.search(r"`chapter_status` 只能是 ([^\n]+)", state).group(1))
    sloka_status = codes(re.search(r"`sloka_status` 只能是 ([^\n]+)", state).group(1))
    coverage_status = codes(re.search(r"`status` 只能是 ([^\n]+)", coverage).group(1))
    return {
        "MANIFEST_REQUIRED": manifest_fields,
        "PARENT_REQUIRED": parent_fields,
        "CARD_REQUIRED": card_fields,
        "COVERAGE_REQUIRED": coverage_fields,
        "PARENT_KIND": parent_kind,
        "CARD_KIND": card_kind,
        "CHAPTER_STATUS": chapter_status,
        "SLOKA_STATUS": sloka_status,
        "TEXT_ROLE": text_roles,
        "COVERAGE_STATUS": coverage_status,
    }


class ContractConsistencyTests(unittest.TestCase):
    def test_gibberish_rule_is_high_precision_and_keeps_formulas_and_english(self):
        self.assertTrue(is_high_confidence_mush("g^fhf % WT^ gi^Pi >211"))
        self.assertTrue(is_high_confidence_mush("fitt qra: ararfaaafa fasi anfa afat f"))
        self.assertFalse(is_high_confidence_mush("ftranw, Bosom friend,"))
        self.assertFalse(is_high_confidence_mush("excessive anger"))
        self.assertFalse(is_high_confidence_mush("The fourth pada is 10°00'–13°20' Aries and falls in Cancer Navamsha."))

    def test_wrapped_lines_merge_across_pages_and_keep_all_source_blocks(self):
        header = "Uttara Kalamritam of Kalidasa 14"
        pages = [
            {"pdf_page": 1, "blocks": [
                {"source_block_id": "H1", "route": "retain_text", "kind": "text", "raw_text": header, "normalized_text": header},
                {"source_block_id": "B1", "route": "retain_text", "kind": "text", "raw_text": "The native obtains wealth when the benefic planet occupies", "normalized_text": "The native obtains wealth when the benefic planet occupies"},
            ]},
            {"pdf_page": 2, "blocks": [
                {"source_block_id": "H2", "route": "retain_text", "kind": "text", "raw_text": "Uttara Kalamritam of Kalidasa 15", "normalized_text": "Uttara Kalamritam of Kalidasa 15"},
                {"source_block_id": "B2", "route": "retain_text", "kind": "text", "raw_text": "the second house and aspects the ascendant.", "normalized_text": "the second house and aspects the ascendant."},
            ]},
            {"pdf_page": 3, "blocks": [
                {"source_block_id": "H3", "route": "retain_text", "kind": "text", "raw_text": "Uttara Kalamritam of Kalidasa 16", "normalized_text": "Uttara Kalamritam of Kalidasa 16"},
            ]},
        ]
        chapter_map = [{"unit_id": "CH1", "chapter_title": "Rules", "raw": "CHAPTER I", "pdf_pages": [1, 3]}]
        running = running_header_source_ids(pages)
        self.assertEqual(running, {"H1", "H2", "H3"})
        paths, _ = heading_paths_for_rows(pages, chapter_map, running)
        units = source_units(pages, chapter_map, paths, True, 1, running)
        merged = next(unit for unit in units if unit["source_block_ids"] == ["B1", "B2"])
        self.assertEqual(merged["pdf_pages"], [1, 2])
        self.assertEqual(merged["raw_text"], "The native obtains wealth when the benefic planet occupies\nthe second house and aspects the ascendant.")
        self.assertEqual(merged["normalized_text"], "The native obtains wealth when the benefic planet occupies the second house and aspects the ascendant.")

    def test_page_furniture_threshold_keeps_running_header_merge_rule_separate(self):
        pages = [
            {"pdf_page": page, "blocks": [{"source_block_id": f"H{page}", "route": "retain_text", "kind": "text", "raw_text": f"Book Header {page}", "normalized_text": f"Book Header {page}"}]}
            for page in range(1, 21)
        ]
        self.assertEqual(len(running_header_source_ids(pages)), 20)
        self.assertEqual(len(page_furniture_source_ids(pages)), 20)

    def test_page_furniture_is_nonindexable_and_validator_enforces_it(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            input_dir = root / "input"
            output_dir = root / "output"
            input_dir.mkdir()
            book_lines = []
            pages = []
            repeated_body = "This repeated rule is legitimate body evidence and remains searchable."
            tags = ("Alpha", "Bravo", "Charlie", "Delta", "Echo", "Foxtrot", "Golf", "Hotel", "India", "Juliet")
            for page, tag in enumerate(tags, 1):
                header = f"Fixture Book {page}"
                blocks = [
                    {"source_block_id": f"H{page}", "route": "retain_text", "kind": "text", "raw_text": header, "normalized_text": header, "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                    {"source_block_id": f"A{page}", "route": "retain_text", "kind": "text", "raw_text": f"Unique opening sentence tagged {tag}.", "normalized_text": f"Unique opening sentence tagged {tag}.", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                    {"source_block_id": f"R{page}", "route": "retain_text", "kind": "text", "raw_text": repeated_body, "normalized_text": repeated_body, "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                    {"source_block_id": f"T{page}", "route": "retain_text", "kind": "text", "raw_text": f"Unique closing sentence tagged {tag}.", "normalized_text": f"Unique closing sentence tagged {tag}.", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                    {"source_block_id": f"F{page}", "route": "retain_text", "kind": "text", "raw_text": f"Unique footer note tagged {tag}.", "normalized_text": f"Unique footer note tagged {tag}.", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                ]
                pages.append({"pdf_page": page, "blocks": blocks})
                book_lines.extend([f"<!-- SOURCE_PAGE {page} -->", "CHAPTER I" if page == 2 else ("Front matter." if page == 1 else ""), header, *[block["raw_text"] for block in blocks[1:]]])
            (input_dir / "book.md").write_text("\n".join(book_lines) + "\n", encoding="utf-8")
            with (input_dir / "pages.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
                for row in pages:
                    handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
            manifest = build({
                "work_id": "FURNITURE_FIXTURE",
                "book_title": "Fixture Book",
                "book_version": "fixture.pdf",
                "source_group": "FURNITURE_FIXTURE",
                "source_pdf_sha256": "0" * 64,
                "case_study_heading_paths": [],
                "body_start_page": 2,
                "merge_wrapped_lines": True,
            }, input_dir, output_dir)
            cards = [json.loads(line) for line in (output_dir / "source_cards.jsonl").read_text(encoding="utf-8").splitlines() if line]
            headers = [card for card in cards if card["page_block"].startswith("H")]
            repeated = [card for card in cards if card["text"] == repeated_body]
            self.assertEqual(len(headers), 10)
            self.assertTrue(all(card["indexable"] is False for card in headers))
            self.assertEqual(len(repeated), 10)
            self.assertTrue(all(card["indexable"] is True for card in repeated))
            self.assertEqual(manifest["heading_context"]["page_furniture_source_blocks"], 10)
            self.assertEqual(validate(output_dir)["status"], "pass")
            headers[0]["indexable"] = True
            all_cards = {card["card_id"]: card for card in cards}
            all_cards[headers[0]["card_id"]] = headers[0]
            with (output_dir / "source_cards.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
                for card in cards:
                    handle.write(json.dumps(all_cards[card["card_id"]], ensure_ascii=False, separators=(",", ":")) + "\n")
            self.assertIn("page_furniture_indexable", validate(output_dir)["failures"])

    def test_quality_gate_does_not_call_inherited_heading_a_misdrop(self):
        cards = [
            {"card_id": "H", "kind": "text", "text": "Second House", "indexable": False, "heading_path": ["CHAPTER I", "Second House"]},
            {"card_id": "P", "kind": "text", "text": "Money, happiness and conversational ability are judged from this house in the source text. The statement remains a complete retrieval paragraph with enough context for the quality gate.", "indexable": True, "heading_path": ["CHAPTER I", "Second House"], "chapter_title": "Houses", "chapter_number": 1},
        ]
        report = evaluate_quality_gate(cards, "FIXTURE")
        self.assertEqual(report["G3"]["count"], 0)

    def test_quality_gate_g5_detects_repeated_short_page_furniture(self):
        normal = [
            {
                "card_id": f"P{number}",
                "kind": "text",
                "text": f"This complete retrieval paragraph number {number} explains a distinct astrological rule with enough ordinary English context to remain a proper searchable unit for the quality gate and its paragraph ratio.",
                "indexable": True,
                "pdf_page": number % 10 + 1,
                "chapter_title": "Rules",
                "chapter_number": 1,
            }
            for number in range(100)
        ]
        furniture = [
            {
                "card_id": f"F{number}",
                "kind": "text",
                "text": f"Example Book Header {number}",
                "indexable": True,
                "pdf_page": number,
                "chapter_title": "Rules",
                "chapter_number": 1,
            }
            for number in range(1, 6)
        ]
        report = evaluate_quality_gate(normal + furniture, "FIXTURE", source_pages=10)
        self.assertEqual(report["G5"]["status"], "fail")
        self.assertEqual(report["G5"]["suspected_furniture_cards"], 5)
        self.assertEqual(report["G5"]["pattern_count"], 1)

    def test_quality_gate_g6_requires_eighty_five_percent_indexable_text_cards(self):
        def cards(indexable_count: int) -> list[dict]:
            return [
                {
                    "card_id": f"C{number}",
                    "kind": "text",
                    "text": f"This complete retrieval paragraph number {number} contains enough ordinary English context to remain a proper searchable unit for the quality gate and the index ratio calculation.",
                    "indexable": number < indexable_count,
                    "pdf_page": number % 10 + 1,
                    "chapter_title": "Rules",
                    "chapter_number": 1,
                }
                for number in range(100)
            ]

        self.assertEqual(evaluate_quality_gate(cards(85), "PASS", 10)["G6"]["status"], "pass")
        self.assertEqual(evaluate_quality_gate(cards(84), "FAIL", 10)["G6"]["status"], "fail")

    def test_assembler_recovers_long_english_header_footer_mislabels(self):
        self.assertIsNone(_discard_reason("header", "English body text " * 12))
        self.assertEqual(_discard_reason("footer", "short footer"), "footer")
        self.assertEqual(_discard_reason("header", "梵文 " * 50), "header")

    def test_numbered_list_unit_splits_by_item_and_preserves_text(self):
        source = " ".join(f"({index}) item {index} with a short explanation." for index in range(1, 80))
        source = source.replace(". (", ", (")
        source = source + " tail."
        self.assertGreater(len(source), 1200)
        chunks = sentence_chunks(source)
        self.assertGreater(len(chunks), 1)
        self.assertTrue(all(len(chunk) <= 1200 for chunk in chunks))
        squash = lambda value: re.sub(r"\s+", " ", value).strip()
        self.assertEqual(squash(" ".join(chunks)), squash(source))

    def test_ordinary_long_sentence_still_fails(self):
        source = "This is one sentence without a safe structural boundary " + ("with more words " * 120)
        self.assertGreater(len(source), 1200)
        with self.assertRaises(ValueError):
            sentence_chunks(source)

    def test_chapter_deals_is_not_a_numbered_chapter(self):
        with tempfile.TemporaryDirectory() as temp:
            book = Path(temp) / "book.md"
            book.write_text(
                "<!-- SOURCE_PAGE 1 -->\nChapter 4\n\n"
                "This Chapter deals with strength.\n\n"
                "Thus ends the fourth chapter.\n",
                encoding="utf-8",
            )
            entries, _ = scan_chapters(book, body_start_page=1)
            self.assertEqual([entry.get("chapter_number") for entry in entries if entry["kind"] == "chapter"], [4])

    def test_declared_chapter_numbers_filter_false_ocr_numbers(self):
        with tempfile.TemporaryDirectory() as temp:
            book = Path(temp) / "book.md"
            book.write_text(
                "<!-- SOURCE_PAGE 1 -->\nChapter 4\n\n"
                "This Chapter deals with strength.\n\n"
                "Chapter 5\n",
                encoding="utf-8",
            )
            sequence = [{"chapter_number": number, "title": f"Chapter {number}"} for number in range(1, 6)]
            entries, report = scan_chapters(book, body_start_page=1, chapter_title_sequence=sequence)
            numbers = [entry.get("chapter_number") for entry in entries if entry["kind"] == "chapter"]
            self.assertEqual(numbers, [4, 5])
            self.assertEqual(report["configured_title_sequence"]["missing"], [{"title": "Chapter 1", "chapter_number": 1, "reason": "missing"}, {"title": "Chapter 2", "chapter_number": 2, "reason": "missing"}, {"title": "Chapter 3", "chapter_number": 3, "reason": "missing"}])

    def test_ordinal_end_markers_supply_missing_next_chapter(self):
        with tempfile.TemporaryDirectory() as temp:
            book = Path(temp) / "book.md"
            book.write_text(
                "<!-- SOURCE_PAGE 1 -->\nChapter 4\n\n"
                "<!-- SOURCE_PAGE 2 -->\nThus ends the fourth chapter.\n\n"
                "<!-- SOURCE_PAGE 3 -->\nChapter 6\n\n"
                "<!-- SOURCE_PAGE 4 -->\nChapter 11\n\n"
                "<!-- SOURCE_PAGE 5 -->\nThus ends the eleventh chapter.\n\n"
                "<!-- SOURCE_PAGE 6 -->\nChapter 13\n\n"
                "<!-- SOURCE_PAGE 7 -->\nThus ends the 16th Adhyaya.\n",
                encoding="utf-8",
            )
            entries, _ = scan_chapters(book, body_start_page=1)
            by_number = {entry.get("chapter_number"): entry for entry in entries if entry["kind"] == "chapter"}
            self.assertEqual(by_number[5]["page"], 3)
            self.assertEqual(by_number[12]["page"], 6)
            self.assertEqual(by_number[16]["page"], 6)

    def test_oversized_numbered_item_still_fails(self):
        source = "(1) " + ("word " * 260) + ", (2) short item."
        self.assertGreater(len(source), 1200)
        with self.assertRaises(ValueError):
            sentence_chunks(source)

    def build_case_fixture(self, root: Path, declared_paths: list[list[str]], include_case_cue: bool = True) -> tuple[Path, list[dict]]:
        input_dir = root / "input"
        output_dir = root / "output"
        input_dir.mkdir()
        (input_dir / "book.md").write_text(
            "<!-- SOURCE_PAGE 1 -->\nFront matter.\n\n<!-- SOURCE_PAGE 2 -->\nCHAPTER I\nTHEORY AND CASES\n",
            encoding="utf-8",
        )
        case_heading = "CASE STUDY 1" if include_case_cue else "CASE AREA"
        pages = [
            {"pdf_page": 1, "blocks": [
                {"source_block_id": "P001_B001", "route": "retain_text", "kind": "text", "raw_text": "Front matter.", "normalized_text": "Front matter.", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
            ]},
            {"pdf_page": 2, "blocks": [
                {"source_block_id": "P002_B001", "route": "retain_text", "kind": "text", "raw_text": "THEORY", "normalized_text": "THEORY", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                {"source_block_id": "P002_B002", "route": "retain_text", "kind": "text", "raw_text": "General principles apply to every ordinary chart and remain theoretical guidance rather than a dated example for one named person. The paragraph is deliberately long enough to be a proper retrieval unit.", "normalized_text": "General principles apply to every ordinary chart and remain theoretical guidance rather than a dated example for one named person. The paragraph is deliberately long enough to be a proper retrieval unit.", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                {"source_block_id": "P002_B003", "route": "retain_text", "kind": "text", "raw_text": case_heading, "normalized_text": case_heading, "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                {"source_block_id": "P002_B004", "route": "retain_text", "kind": "text", "raw_text": "A specific person experienced the dated event and the source explains the observation in enough detail to form a proper retrieval paragraph without borrowing words from any other section.", "normalized_text": "A specific person experienced the dated event and the source explains the observation in enough detail to form a proper retrieval paragraph without borrowing words from any other section.", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                {"source_block_id": "P002_B005", "route": "retain_text", "kind": "text", "raw_text": "Details", "normalized_text": "Details", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                {"source_block_id": "P002_B006", "route": "retain_text", "kind": "text", "raw_text": "The dated event is described here with the original circumstances, timing and result preserved as one complete paragraph suitable for retrieval and later citation back to the source page.", "normalized_text": "The dated event is described here with the original circumstances, timing and result preserved as one complete paragraph suitable for retrieval and later citation back to the source page.", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                {"source_block_id": "P002_B007", "route": "retain_text", "kind": "text", "raw_text": "FURTHER THEORY", "normalized_text": "FURTHER THEORY", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                {"source_block_id": "P002_B008", "route": "retain_text", "kind": "text", "raw_text": "Another general rule applies across charts and remains outside the case study. This paragraph is long enough to prove that the nearby case heading does not contaminate the following theoretical section.", "normalized_text": "Another general rule applies across charts and remains outside the case study. This paragraph is long enough to prove that the nearby case heading does not contaminate the following theoretical section.", "transformations": [], "asset_path": None, "reason": None, "table_rows": []},
                *[
                    {
                        "source_block_id": f"P002_B{number:03d}",
                        "route": "retain_text",
                        "kind": "text",
                        "raw_text": f"Independent theory paragraph {number} explains a separate general rule with enough complete English context to be indexed as a normal source card without belonging to the nearby case study section.",
                        "normalized_text": f"Independent theory paragraph {number} explains a separate general rule with enough complete English context to be indexed as a normal source card without belonging to the nearby case study section.",
                        "transformations": [],
                        "asset_path": None,
                        "reason": None,
                        "table_rows": [],
                    }
                    for number in range(9, 33)
                ],
            ]},
        ]
        with (input_dir / "pages.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
            for row in pages:
                handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
        build({
            "work_id": "CASE_FIXTURE",
            "book_title": "Case Fixture",
            "author": "Test",
            "book_version": "book.pdf",
            "source_pdf_sha256": "0" * 64,
            "body_start_page": 2,
            "case_study_heading_paths": declared_paths,
        }, input_dir, output_dir)
        cards = [json.loads(line) for line in (output_dir / "source_cards.jsonl").read_text(encoding="utf-8").splitlines() if line]
        return output_dir, cards

    def test_contract_matches_validator_constants(self):
        contract_text = CONTRACT.read_text(encoding="utf-8")
        self.assertIn("# contract_v2.1", contract_text)
        self.assertIn("quality_gate_report.json", contract_text)
        self.assertEqual(CONTRACT_VERSION, "contract_v2.1")
        documented = contract_values(CONTRACT)
        implemented = {
            "MANIFEST_REQUIRED": MANIFEST_REQUIRED,
            "PARENT_REQUIRED": PARENT_REQUIRED,
            "CARD_REQUIRED": CARD_REQUIRED,
            "COVERAGE_REQUIRED": COVERAGE_REQUIRED,
            "PARENT_KIND": PARENT_KIND,
            "CARD_KIND": CARD_KIND,
            "CHAPTER_STATUS": CHAPTER_STATUS,
            "SLOKA_STATUS": SLOKA_STATUS,
            "TEXT_ROLE": TEXT_ROLE,
            "COVERAGE_STATUS": COVERAGE_STATUS,
        }
        for name, code_value in implemented.items():
            doc_value = tuple(documented[name])
            code_value = tuple(code_value)
            missing = sorted(set(code_value) - set(doc_value))
            extra = sorted(set(doc_value) - set(code_value))
            same = set(doc_value) == set(code_value) if name.endswith(("_KIND", "_STATUS", "TEXT_ROLE")) else doc_value == code_value
            self.assertEqual(
                same,
                True,
                f"{name} 不一致：文档值={doc_value}；代码值={code_value}；文档缺少={missing}；文档多出={extra}",
            )

    def test_retrieval_validator_constants_match_cutting_validator(self):
        if not PEER_VALIDATOR.is_file():
            self.skipTest("检索 skill 未安装；联调环境存在时自动对账两侧验收常量")
        peer = load_peer_validator()
        self.assertEqual(peer.CONTRACT_VERSION, CONTRACT_VERSION)
        self.assertIn("quality_gate_report.json", peer.MINIMUM_FILES)
        for name in ("MANIFEST_REQUIRED", "PARENT_REQUIRED", "CARD_REQUIRED", "COVERAGE_REQUIRED", "CHAPTER_STATUS", "SLOKA_STATUS"):
            self.assertEqual(set(getattr(peer, name)), set(globals()[name]), f"检索侧 {name} 与切书侧不一致")

    def test_two_contract_copies_are_identical(self):
        if not PEER_CONTRACT.is_file():
            self.skipTest("独立切书 skill 包未安装检索侧；联调环境存在副本时自动逐字对账")
        self.assertEqual(
            CONTRACT.read_bytes(),
            PEER_CONTRACT.read_bytes(),
            "两边 PACKAGE_CONTRACT.md 不是逐字相同副本",
        )

    def test_case_study_prefix_matching(self):
        declared = [["CHAPTER I", "THEORY AND CASES", "CASE STUDY 1"]]
        self.assertFalse(case_study_for_heading_path(["CHAPTER I", "THEORY AND CASES", "THEORY"], declared))
        self.assertTrue(case_study_for_heading_path(["CHAPTER I", "THEORY AND CASES", "CASE STUDY 1"], declared))
        self.assertTrue(case_study_for_heading_path(["CHAPTER I", "THEORY AND CASES", "CASE STUDY 1", "Details"], declared))
        self.assertFalse(case_study_for_heading_path(["CHAPTER I", "THEORY AND CASES", "FURTHER THEORY"], declared))

    def test_case_study_gap_reports_continuous_siblings_and_accepts_complete_paths(self):
        cards = [
            {"card_id": "OPEN", "heading_path": ["CHAPTER I", "CASES", "Case Opening"], "text": "So let this book conclude with a recent reading I gave to a client."},
            {"card_id": "GENERAL", "heading_path": ["CHAPTER I", "CASES", "General Trends"], "text": "1. The client reports this trend."},
            {"card_id": "PROF", "heading_path": ["CHAPTER I", "CASES", "Profession"], "text": "Profession is discussed here."},
            {"card_id": "HEALTH", "heading_path": ["CHAPTER I", "CASES", "Health"], "text": "Health is discussed here."},
        ]
        opening_only = case_study_config_gaps(cards, [["CHAPTER I", "CASES", "Case Opening"]])
        missing = {tuple(item["heading_path"]) for item in opening_only}
        self.assertEqual(missing, {
            ("CHAPTER I", "CASES", "General Trends"),
            ("CHAPTER I", "CASES", "Profession"),
            ("CHAPTER I", "CASES", "Health"),
        })
        complete = case_study_config_gaps(cards, [
            ["CHAPTER I", "CASES", "Case Opening"],
            ["CHAPTER I", "CASES", "General Trends"],
            ["CHAPTER I", "CASES", "Profession"],
            ["CHAPTER I", "CASES", "Health"],
        ])
        self.assertEqual(complete, [])

    def test_case_study_gap_ignores_standalone_you_or_your(self):
        cards = [{
            "card_id": "THEORY",
            "heading_path": ["CHAPTER I", "THEORY"],
            "text": "Your horoscope may show many tendencies.",
        }]
        self.assertEqual(case_study_config_gaps(cards, []), [])

    def test_generator_outputs_case_flags_and_does_not_pollute_peer_theory(self):
        with tempfile.TemporaryDirectory() as temp:
            root, cards = self.build_case_fixture(Path(temp), [["CHAPTER I", "THEORY AND CASES", "CASE STUDY 1"]])
            by_block = {card["page_block"]: card for card in cards}
            self.assertFalse(by_block["P002_B002"]["is_case_study"])
            self.assertTrue(by_block["P002_B004"]["is_case_study"])
            self.assertTrue(by_block["P002_B006"]["is_case_study"])
            self.assertFalse(by_block["P002_B008"]["is_case_study"])
            self.assertEqual(validate(root)["status"], "pass")

    def test_empty_case_config_still_outputs_explicit_false(self):
        with tempfile.TemporaryDirectory() as temp:
            root, cards = self.build_case_fixture(Path(temp), [], include_case_cue=False)
            self.assertTrue(cards)
            self.assertTrue(all(card.get("is_case_study") is False for card in cards))
            self.assertEqual(validate(root)["status"], "pass")

    def test_validator_rejects_missing_wrong_type_and_wrong_assignment(self):
        mutations = {
            "missing": lambda card: card.pop("is_case_study"),
            "wrong_type": lambda card: card.__setitem__("is_case_study", "false"),
            "wrong_assignment": lambda card: card.__setitem__("is_case_study", not card["is_case_study"]),
        }
        for label, mutate in mutations.items():
            with self.subTest(label=label), tempfile.TemporaryDirectory() as temp:
                root, cards = self.build_case_fixture(Path(temp), [["CHAPTER I", "THEORY AND CASES", "CASE STUDY 1"]])
                mutate(cards[0])
                with (root / "source_cards.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
                    for card in cards:
                        handle.write(json.dumps(card, ensure_ascii=False, separators=(",", ":")) + "\n")
                with contextlib.redirect_stdout(io.StringIO()):
                    result = validate(root)
                self.assertEqual(result["status"], "fail")

    def test_retrieval_validator_rejects_missing_and_wrong_case_type(self):
        if not PEER_VALIDATOR.is_file():
            self.skipTest("检索 skill 未安装；联调环境存在时自动验证下游拒绝旧字段包")
        peer = load_peer_validator()
        for label, value in (("missing", None), ("wrong_type", "false")):
            with self.subTest(label=label), tempfile.TemporaryDirectory() as temp:
                base = Path(temp)
                root, cards = self.build_case_fixture(base, [])
                if label == "missing":
                    cards[0].pop("is_case_study")
                else:
                    cards[0]["is_case_study"] = value
                with (root / "source_cards.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
                    for card in cards:
                        handle.write(json.dumps(card, ensure_ascii=False, separators=(",", ":")) + "\n")
                zip_path = base / "fixture.zip"
                package(root, zip_path)
                with self.assertRaises(ValueError):
                    peer.validate(zip_path, "CASE_FIXTURE")

    def test_package_refuses_zip_when_g6_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            root, cards = self.build_case_fixture(base, [])
            parent_id = cards[0]["parent_id"]
            for number in range(10):
                image = dict(cards[0])
                image.update({
                    "card_id": f"IMAGE_{number}",
                    "parent_id": parent_id,
                    "kind": "image",
                    "text_role": "asset",
                    "text": "",
                    "raw_text": "",
                    "indexable": False,
                })
                cards.append(image)
            with (root / "source_cards.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
                for card in cards:
                    handle.write(json.dumps(card, ensure_ascii=False, separators=(",", ":")) + "\n")
            zip_path = base / "blocked.zip"
            with self.assertRaisesRegex(ValueError, "G1-G3、G5、G6"):
                package(root, zip_path)
            self.assertFalse(zip_path.exists())

    def test_active_scripts_have_no_book_page_or_case_heading_special_cases(self):
        forbidden = re.compile(r"ASTROLOGY_DESTINY_WHEEL_OF_TIME|LAGHU_PARASHARI_VERMA|Case Study :|if\s+[^\n]*\bpage\s*==\s*\d+|if\s+[^\n]*(?:work_id|book_title)\s*==")
        hits = []
        for path in sorted((ROOT / "scripts").glob("*.py")):
            if forbidden.search(path.read_text(encoding="utf-8")):
                hits.append(path.name)
        self.assertEqual(hits, [], f"活跃脚本仍含某书、固定页码或固定案例标题特判: {hits}")

    def test_discard_report_scans_real_blocks_and_thresholds(self):
        result = discard_misdrop_report([
            {"source_block_id": "SHORT", "text": "short"},
            {"source_block_id": "ZH", "text": "中文 " * 50},
            {"source_block_id": "SUSPECT", "text": "word " * 80},
        ])
        self.assertEqual(result["scanned_blocks"], 3)
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["items"][0]["source_block_id"], "SUSPECT")
        self.assertEqual(result["status"], "fail")

    def test_has_sloka_is_always_program_decided(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "book.md"
            path.write_text("CHAPTER I\nordinary prose\n", encoding="utf-8")
            result = detect_has_sloka(path)
        self.assertIsInstance(result["decision"], bool)
        self.assertNotIn("gray_zone", result)
        self.assertNotIn("gray_zone_override", result)

    def test_sloka_marker_accepts_unicode_and_ascii_half_ranges(self):
        self.assertEqual(first_sloka("7-8½. text"), "7-8½")
        self.assertEqual(first_sloka("7-81/2. text"), "7-81/2")
        self.assertEqual(first_sloka("15-16 1/2. text"), "15-16 1/2")

    def test_sloka_marker_does_not_inherit_from_non_marker_text(self):
        self.assertIsNone(first_sloka("ordinary prose mentioning 7-8½ later."))

    def test_heading_path_covers_indexable_and_non_indexable_titles_until_peer_or_chapter(self):
        chapter_map = [
            {"unit_id": "CH1", "chapter_title": "House Meanings", "raw": "CHAPTER I", "pdf_pages": [1, 1]},
            {"unit_id": "CH2", "chapter_title": "Next Chapter", "raw": "CHAPTER II", "pdf_pages": [2, 2]},
        ]
        pages = [
            {"pdf_page": 1, "blocks": [
                {"source_block_id": "B1", "route": "retain_text", "kind": "text", "raw_text": "Second House", "normalized_text": "Second House"},
                {"source_block_id": "B2", "route": "retain_text", "kind": "text", "raw_text": "Money, happiness, truth.", "normalized_text": "Money, happiness, truth."},
                {"source_block_id": "B3", "route": "retain_text", "kind": "text", "raw_text": "Fortunes, pilgrimages.", "normalized_text": "Fortunes, pilgrimages."},
                {"source_block_id": "B4", "route": "retain_text", "kind": "text", "raw_text": "Ninth House", "normalized_text": "Ninth House"},
                {"source_block_id": "B5", "route": "retain_text", "kind": "text", "raw_text": "Good fortune follows.", "normalized_text": "Good fortune follows."},
            ]},
            {"pdf_page": 2, "blocks": [
                {"source_block_id": "B6", "route": "retain_text", "kind": "text", "raw_text": "Fresh content.", "normalized_text": "Fresh content."},
            ]},
        ]
        paths, report = heading_paths_for_rows(pages, chapter_map)
        self.assertEqual(paths["B2"], ["CHAPTER I", "House Meanings", "Second House"])
        self.assertEqual(paths["B3"], paths["B2"])
        self.assertEqual(paths["B5"], ["CHAPTER I", "House Meanings", "Ninth House"])
        self.assertEqual(paths["B6"], ["CHAPTER II", "Next Chapter"])
        self.assertEqual(report["heading_blocks"], 2)

    def test_heading_path_keeps_upper_parent_and_replaces_title_case_peer(self):
        chapter_map = [{"unit_id": "CH1", "chapter_title": "Rules", "raw": "CHAPTER I", "pdf_pages": [1, 1]}]
        pages = [{"pdf_page": 1, "blocks": [
            {"source_block_id": "B1", "route": "retain_text", "kind": "text", "raw_text": "HOUSE RESULTS", "normalized_text": "HOUSE RESULTS"},
            {"source_block_id": "B2", "route": "retain_text", "kind": "text", "raw_text": "Second House", "normalized_text": "Second House"},
            {"source_block_id": "B3", "route": "retain_text", "kind": "text", "raw_text": "Money and happiness.", "normalized_text": "Money and happiness."},
            {"source_block_id": "B4", "route": "retain_text", "kind": "text", "raw_text": "Ninth House", "normalized_text": "Ninth House"},
            {"source_block_id": "B5", "route": "retain_text", "kind": "text", "raw_text": "Fortune and pilgrimage.", "normalized_text": "Fortune and pilgrimage."},
        ]}]
        paths, _ = heading_paths_for_rows(pages, chapter_map)
        self.assertEqual(paths["B3"], ["CHAPTER I", "Rules", "HOUSE RESULTS", "Second House"])
        self.assertEqual(paths["B5"], ["CHAPTER I", "Rules", "HOUSE RESULTS", "Ninth House"])

    def test_chapter_map_gives_section_boundary_its_own_page_and_isolates_number_gap(self):
        entries = [
            {"kind": "chapter", "page": 14, "raw": "CHAPTER III", "normalized": "CHAPTER III", "title": "Story", "chapter_number": 3, "section": {"section_number": "I", "section_title": "Section I"}, "changes": [], "evidence_source": ["title"]},
            {"kind": "section", "page": 25, "raw": "SECTION II", "normalized": "SECTION II", "title": "Section II", "section": {"section_number": "II", "section_title": "Section II"}, "changes": []},
            {"kind": "chapter", "page": 68, "raw": "CHAPTER XIII", "normalized": "CHAPTER XIII", "title": "Thirteen", "chapter_number": 13, "section": {"section_number": "II", "section_title": "Section II"}, "changes": [], "evidence_source": ["title"]},
            {"kind": "chapter", "page": 75, "raw": "CHAPTER XV", "normalized": "CHAPTER XV", "title": "Fifteen", "chapter_number": 15, "section": {"section_number": "II", "section_title": "Section II"}, "changes": [], "evidence_source": ["title"]},
        ]
        chapter_map, _ = build_map(entries, 80, body_start_page=6, has_sloka=False)
        page_counts = Counter(page for entry in chapter_map for page in range(entry["pdf_pages"][0], entry["pdf_pages"][1] + 1))
        self.assertTrue(all(page_counts[page] == 1 for page in range(1, 81)))
        self.assertEqual(next(entry["pdf_pages"] for entry in chapter_map if entry.get("chapter_number") == 3), [14, 24])
        self.assertEqual(next(entry["pdf_pages"] for entry in chapter_map if entry.get("chapter_number") == 13), [68, 68])
        self.assertEqual(next(entry["pdf_pages"] for entry in chapter_map if entry.get("chapter_number") == 14), [69, 74])

    def test_chapter_map_merges_same_page_multi_chapter_spans_as_one_unknown(self):
        def entry(page, number, section):
            return {
                "kind": "chapter",
                "page": page,
                "raw": f"CHAPTER {number}",
                "normalized": f"CHAPTER {number}",
                "title": f"Chapter {number}",
                "chapter_number": number,
                "section": {"section_number": section, "section_title": f"Section {section}"},
                "changes": [],
                "evidence_source": ["title"],
            }

        entries = [
            entry(20, 6, "I"),
            entry(20, 7, "I"),
            entry(22, 8, "I"),
            entry(166, 43, "II"),
            entry(166, 44, "II"),
            entry(166, 45, "II"),
            entry(170, 46, "II"),
        ]
        chapter_map, checks = build_map(entries, 170, body_start_page=6, has_sloka=False)
        page_counts = Counter(page for item in chapter_map for page in range(item["pdf_pages"][0], item["pdf_pages"][1] + 1))
        self.assertTrue(all(page_counts[page] == 1 for page in range(1, 171)))
        self.assertEqual(sum(1 for item in chapter_map if item["unit_id"] == "UNKNOWN_SHARED_20"), 1)
        self.assertEqual(sum(1 for item in chapter_map if item["unit_id"] == "UNKNOWN_SHARED_166"), 1)
        self.assertEqual(next(item["pdf_pages"] for item in chapter_map if item["unit_id"] == "UNKNOWN_SHARED_20"), [20, 21])
        self.assertEqual(next(item["pdf_pages"] for item in chapter_map if item["unit_id"] == "UNKNOWN_SHARED_166"), [166, 169])
        self.assertEqual(checks["unknown_pages"], sum(
            item["pdf_pages"][1] - item["pdf_pages"][0] + 1
            for item in chapter_map
            if item["chapter_status"] == "unknown"
        ))
        self.assertEqual(checks["unknown_page_ratio"], round(checks["unknown_pages"] / 170, 6))

    def test_configured_bare_title_sequence_builds_ordered_map(self):
        with tempfile.TemporaryDirectory() as temp:
            book = Path(temp) / "book.md"
            book.write_text(
                "<!-- SOURCE_PAGE 1 -->\nFront\n\n"
                "<!-- SOURCE_PAGE 2 -->\nAlpha\n\nAlpha prose.\n\n"
                "<!-- SOURCE_PAGE 3 -->\nBeta\n\nBeta prose.\n\n"
                "<!-- SOURCE_PAGE 4 -->\nGamma\n\nGamma prose.\n\n"
                "<!-- SOURCE_PAGE 5 -->\nAppendix\n\nAppendix prose.\n",
                encoding="utf-8",
            )
            sequence = [
                {"title": "Alpha", "chapter_number": 1},
                {"title": "Beta", "chapter_number": 2},
                {"title": "Gamma", "chapter_number": 3},
                {"title": "Appendix", "chapter_number": None},
            ]
            entries, scan = scan_chapters(book, 2, sequence)
            self.assertEqual([entry["title"] for entry in entries], ["Alpha", "Beta", "Gamma", "Appendix"])
            self.assertEqual([entry["page"] for entry in entries], [2, 3, 4, 5])
            self.assertEqual(scan["configured_title_sequence"]["missing"], [])
            self.assertEqual(scan["configured_title_sequence"]["ambiguities"], [])
            chapter_map, checks = build_map(entries, 5, body_start_page=2, has_sloka=False)
            self.assertEqual(checks["unknown_pages"], 0)
            self.assertTrue(all(item["chapter_status"] == "confirmed" for item in chapter_map))
            self.assertTrue(all("configured_title_sequence" in item["evidence_source"] for item in chapter_map[1:]))

    def test_configured_sequence_requires_exact_standalone_title_and_reports_missing(self):
        with tempfile.TemporaryDirectory() as temp:
            book = Path(temp) / "book.md"
            book.write_text(
                "<!-- SOURCE_PAGE 1 -->\nFront\n\n"
                "<!-- SOURCE_PAGE 2 -->\nAlpha\n\n"
                "<!-- SOURCE_PAGE 3 -->\nBeta appears in ordinary prose.\n\n"
                "<!-- SOURCE_PAGE 4 -->\nGamma\n",
                encoding="utf-8",
            )
            entries, scan = scan_chapters(book, 2, [
                {"title": "Alpha", "chapter_number": 1},
                {"title": "Beta", "chapter_number": 2},
                {"title": "Gamma", "chapter_number": 3},
            ])
            self.assertEqual([entry["title"] for entry in entries], ["Alpha", "Gamma"])
            self.assertEqual(scan["configured_title_sequence"]["missing"], [{"title": "Beta", "chapter_number": 2, "reason": "missing"}])

    def test_configured_sequence_reports_order_backtrack_without_guessing(self):
        with tempfile.TemporaryDirectory() as temp:
            book = Path(temp) / "book.md"
            book.write_text(
                "<!-- SOURCE_PAGE 1 -->\nFront\n\n"
                "<!-- SOURCE_PAGE 2 -->\nBeta\n\n"
                "<!-- SOURCE_PAGE 3 -->\nGamma\n",
                encoding="utf-8",
            )
            entries, scan = scan_chapters(book, 2, [
                {"title": "Gamma", "chapter_number": 2},
                {"title": "Beta", "chapter_number": 3},
            ])
            self.assertEqual([entry["title"] for entry in entries], ["Gamma"])
            self.assertEqual(scan["configured_title_sequence"]["order_backtracks"], [{"title": "Beta", "chapter_number": 3, "reason": "order_backtrack"}])

    def test_configured_sequence_validation_rejects_bad_items(self):
        with self.assertRaises(ValueError):
            normalize_chapter_title_sequence([{"title": "", "chapter_number": 1}])
        with self.assertRaises(ValueError):
            normalize_chapter_title_sequence([{"title": "Alpha", "chapter_number": 0}])


if __name__ == "__main__":
    unittest.main()
