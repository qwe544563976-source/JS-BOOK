---
name: vedic-book-distiller
description: Deterministic PDF-to-clean-source-card workflow for books. Use when Codex must lock a PDF, run preflight and text-layer checks, route to configured MinerU CUDA OCR when needed, build a two-stage chapter map, slice parent/child evidence cards, validate five hard gates, and emit one validated ZIP for downstream retrieval.
---

# MD工具 · 星占规则卡

只做 PDF → 干净原文卡；下游检索由独立 skill 负责，唯一接口是验收通过的成品 ZIP。

每次开工先读 skill 同级目录的 `../STATUS.md`；文件存在时只更新其中“切书侧”一节，不存在时直接按本 skill 执行。

环境与工具只认 [`references/TOOLS.md`](references/TOOLS.md)：C 盘 `C:\Users\aa\.codex\skills\vedic-book-distiller` 是 Codex 正式版，J 盘 `J:\洗书工作区V2\skills\vedic-book-distiller` 是同步镜像。开工禁止扫描全盘、重复找 MinerU 或另装环境。

下一条命令（陌生书冷启动）：

```bash
python scripts/run_book.py --config <work-dir>/book_config.json --pdf <work-dir>/book.pdf
```

流程固定为：`preflight → 三页文字层体检 → MinerU txt/ocr 路由 → 10 页样本 → 整本 → 章节地图 → 父子切片/表格路由 → validate → ZIP`。MinerU 只能使用配置里的 Python；OCR 只走 CUDA，CUDA 不可用就失败，不回退 CPU。

三铁律：

1. 锁定输入 PDF、页数和 SHA；程序回填书名、章节、页码、段号和原文，模型不得猜。
2. 章节先全书收证据建边界表、自检后统一回填；正文标题决定边界，目录只核对章数；`unknown` 合法，无法归章正文页超过 5% 才停。
3. `raw_text` 原样留存；确定性修复逐条写 `normalized_text`/`transformations`。固定修复只插空格或归一大小写，严禁 `I/1`、`O/0` 替换。

禁止事项：不把旧 manifest 的 chapter_map 当生成输入；不引入新依赖；不新增 OCR 备用路线、静默重试、第二事实源或 RAG 数据；不把星盘几何图拍平成检索文本；不把短卡、unknown 或软耗时当失败；状态字段必须由上游明确产出，不能让下游按章号或偈号猜。

正式成品 ZIP 的唯一字段与状态契约见 [`references/PACKAGE_CONTRACT.md`](references/PACKAGE_CONTRACT.md)，版本必须为 `contract_v2.1`。每次出包固定执行“切片 → G1-G3、G5、G6 入库质量门 → ZIP”；质量门报告必须随包，任一硬门失败不得交付。高置信 OCR 乱码只设为不可检索，不删除；低置信疑似项只进入报告交解读层。行级文字层需要段落缝合时使用通用 `merge_wrapped_lines`，父段登记全部成员源块并允许有证据的跨页续句。每页首尾的短文本若在至少 10% 页面重复（且不少于 5 页），按数字序列归一后判为页面家具，只设为不可检索并单独计数；正文中重复出现的合法定式不受影响。`heading_path` 由程序按原书块顺序和标题层级生成，模型不得参与。每本书配置必须显式填写 `case_study_heading_paths`，无案例也填 `[]`；生成器只按标题路径前缀写出每张卡的布尔字段 `is_case_study`，不读正文猜案例。验收器另做高精度“案例区域漏登记”检查：独立的 `Case Study`/`Case Summary` 标题、明确的 `recent reading I gave`/`please write your remarks`，以及位于标题区域前部且由明确引入句开启的 `horoscope of` 人名，若未登记则硬失败并列出 `heading_path`；recent reading/remarks 引导的同一父标题后续兄弟小标题也必须登记。单独 `you/your`、目录里的 case study 和理论段中泛泛提及不触发，检查只报告不自动改卡。

旧包升级固定走“回到最早仍可信的事实源再组装”：优先复用同一 PDF 对应的 `book.md + pages.jsonl` 或 MinerU `content_list`，只重跑章节地图、标题链、父子切片、验收和打包；块级事实源存在时不得重跑 OCR。若旧包只剩逐父段 `raw_text`、原始 `source_block_ids` 和全量 coverage，且旧丢弃路由已验收，可用 `scripts/rebuild_precontract.py` 重切卡；manifest 必须明写“沿用旧丢弃路由、未重新扫描丢弃原文”。禁止从旧卡相邻关系猜 `heading_path`，也禁止只补字段冒充 `contract_v2.1`。

纯提速 A/B 要求 raw 逐字零差异、五门全过且耗时下降；质量修正 A/B 允许登记差异，但必须逐项写 `source_recovery`/`ab_validation`，除登记项外未登记 raw 差异必须为 0。

交付前先读 [`references/PACKAGE_CONTRACT.md`](references/PACKAGE_CONTRACT.md)。它与 `vedic-evidence-retrieval/reference/PACKAGE_CONTRACT.md` 必须逐字一致；先切书验收，再把 ZIP 交给检索侧验收。字段语义或格式变化时两边同步升版本；实现已存在但文档遗漏的勘误不升版本，但必须同步副本并写决策记录。

详细契约和失败处理见 `references/PACKAGE_CONTRACT.md`；`references/contract.md` 只提供兼容入口。操作步骤见 `references/TUTORIAL.md`，固定规则见 `references/TOOLS.md` 和 `references/decisions.md`。

## 共享契约纪律与联调

切书侧契约文件是唯一事实源；任一方修改后必须直接同步检索侧副本并写决策记录。字段语义或格式变化才升版本，文档勘误不升版本。检索侧必须按契约原值读取，不能自行推导 `chapter_status`、`sloka_status` 或其他状态。

未收到检索侧签收前不打正式 ZIP。双方封版前共同做联调冷启动：全新 AI、两个 skill、一本未处理 PDF，只给一句“用这两个 skill 把这本书洗完入库，然后查一个测试问题”；全程无需追问且返回带正确 citation 才算通过。卡在交界处即契约缺漏，补契约重测；同一交界连续三轮不过，停机并出报告。
