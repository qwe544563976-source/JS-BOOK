# 错误分类账（最小版）

- `INPUT-SHA`: PDF 路径、页数或 SHA 不匹配；停止，不换底本。
- `CUDA-ONLY`: MinerU Python 的 CUDA 探针失败；停止，不回退 CPU。
- `ASSET-MISSING`: `status=asset` 的 `asset_path` 空或不存在；直接失败。
- `DISCARD-MISDROP`: 丢弃块满足长度/英文比例阈值；清单必须为 0。
- `CHAPTER-UNKNOWN`: 正文无可靠标题证据；保留卡并标 unknown，比例超过 5% 才停。
- `AB-RAW-DIFF`: pure_speed 出现 raw 差异；失败。quality_correction 的差异必须在 `source_recovery` 登记。

脚本跑完不等于通过；只能以落盘 manifest、coverage、卡字段和 validate 返回码为准。

| 类别 | 现象 | 根因 | 流程修法 | 自动检查 |
|---|---|---|---|---|
| `MINERU-EMPTY-ASSET` | MinerU 的 table 块存在但 `img_path` 为空，组装中止 | 组装器把所有图表类块都假定为必有图片 | 有图才存资产；无图有正文按正文/表格保留；两者都无则明确 discard | `status=asset` 仍强制要求真实 `asset_path`，空图块不得进入 asset 路由 |
| `CHAPTER-MAP-GAP` | 一个章标题都未识别，旧报告却显示 unknown=0 | unknown 只统计地图已有条目，未统计地图未覆盖页 | 建图后对全书页集合补差，所有缺口生成 unknown 区间 | `unknown_page_ratio` 由全 PDF 未覆盖页计算，超过 5% 自动失败 |
| `CONTRACT-UPGRADE-REBUILD` | 给 BPHS 只加新字段时，通用重建曾改变 20 余条 citation 并让 unknown 超过 5% | 字段升级误走整包重建，覆盖了 BPHS 原有已验收章节地图 | 已验收旧包只做元数据迁移；未来新书由主流水线直接生成 v2 | 提升前逐卡比较 `raw_text/text/citation/text_sha256`，任一变化即禁止覆盖原包 |
