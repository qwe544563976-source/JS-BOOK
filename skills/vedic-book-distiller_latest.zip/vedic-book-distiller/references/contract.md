# 成品 ZIP 契约入口

正式且唯一的共享契约是 [`PACKAGE_CONTRACT.md`](PACKAGE_CONTRACT.md)，版本为 `contract_v2.1`。

本文件只保留兼容入口，不复制字段、状态或验收规则正文；若与其他说明冲突，以 `PACKAGE_CONTRACT.md` 为准。旧包没有 `contract_version=contract_v2.1` 时不得作为当前正式包交付。
