# 从零洗一本新书

先说结论：每本新书只收 PDF 和一份书级配置；配置里除书名资料外，必须人工抄入原书真实的案例标题路径。MinerU Python、输出根目录等属于一次性环境配置，不重复问每本书。

| 人只需提供 | 示例 |
|---|---|
| PDF 路径 | `<work>/book.pdf` |
| `work_id` | `EXAMPLE_BOOK` |
| 书名 | `Example Book` |
| 作者 | `Example Author` |
| 案例标题路径 | `[["Birth Rectification", "Case Study 1"]]`；无案例填 `[]` |
| 裸章节标题序列 | 可选：`[{"title":"Ashvini","chapter_number":1}]`；没有 `CHAPTER`/`SECTION` 前缀的书才填写 |

SHA、页数、`book_version`（默认取 PDF 文件名）、`source_group`（默认等于 `work_id`）、`has_sloka`、章节地图、状态字段、citation、验收和 ZIP 均由程序生成。案例区域不从正文猜：人工只抄原书真实标题链到 `case_study_heading_paths`，程序负责其下属卡片的 `is_case_study`。裸章节标题序列只接受目录声明且正文独立块逐字命中的标题，按声明顺序取首次命中；缺失、倒退或歧义写入 `chapter_scan`，不猜页码。超出上表的每书人工判断都视为待自动化项。

先复制 `config/book.example.json` 为本书 `book_config.json`。检查目录和正文标题：只声明明确属于具体人物案例的章节或小节；同一章理论与案例混排时，只声明案例小节。路径必须与生成后的 `heading_path` 原文逐字一致，支持前缀覆盖其子标题；没有案例章节也不能省略字段，必须填空数组。

验收器会检查案例标题漏登：独立的 `Case Study`/`Case Summary` 标题、`recent reading I gave`、`please write your remarks`，以及标题区域前部由明确引入句开启的 `horoscope of` 人名，未在 `case_study_heading_paths` 登记就失败，并在结果的 `checks.case_study_config_gaps` 列出原始 `heading_path` 和触发语。`recent reading`/`remarks` 开始后，同一父标题下的连续兄弟小标题也要逐一登记。单独 `you/your`、目录中的 case study 或理论段泛泛提及不触发；检查只报漏项，不自动把卡改成案例。

以下命令在 skill 根目录执行；本机 MinerU 路径只在 `config/defaults.json` 配一次，不写死进代码。

```bash
python scripts/preflight.py --pdf <work>/book.pdf --output <work>/preflight.json
python scripts/run_book.py --config <work>/book_config.json --pdf <work>/book.pdf
python scripts/validate.py <work>/distill
```

通过判据：`run_book.py` 自动完成 MinerU 组装、结构验收、G1-G3、G5、G6 入库质量门和 ZIP，最后输出 `{"status":"pass"}`；`quality_gate_report.json` 必须随包且五项全为 `pass`。G5 检查仍混在可检索卡里的高频短页眉页脚，比例不得超过 3%；G6 检查可检索文本卡占全部源卡的比例，不得低于 85%。任一失败都不生成 ZIP。G1 因“一行一卡”失败时，在书级配置加入 `"merge_wrapped_lines": true` 后从现有 `book.md + pages.jsonl` 重切，不重跑 OCR；程序会保留全部成员源块并缝合明确的跨页续句。G2 命中只把高置信乱码设为不可检索，疑似清单留给解读层。G3 中已经作为 `heading_path` 继承给正文的结构标题不算误丢。

冷启动测试考的是流程是否自主、报得准；陌生 PDF 本身不合格而被真实硬门拒绝，也算测试通过，禁止为拿绿灯削弱门槛。

`has_sloka` 不是人工字段。程序会登记数字段首命中数/总段数/占比，同时检查最长近连续编号链、最大编号、`Sloka/Verse` 明示词和 `½`/区间证据；固定规则直接输出 true 或 false，不暂停等待人工 override，也不写灰区状态。

若已有稳定基线，纯提速对照：

```bash
python scripts/run_book.py --config <work>/book.json --input-dir <work> --output <work>/distill_ab --ab-mode pure_speed --baseline <stable>/manifest.json
```

质量修正必须改用 `--ab-mode quality_correction`，并在 manifest 的 `source_recovery` 登记每个差异。

## 成品交付前的共享契约门

1. 先按 [`PACKAGE_CONTRACT.md`](PACKAGE_CONTRACT.md) 生成 `contract_version=contract_v2.1` 的包；每个父段和原文卡必须显式带 `heading_path`，每张原文卡还必须带布尔 `is_case_study`。manifest 必须保存本书 `case_study_heading_paths`，供两侧验收器重算对账。
2. 检查 image 空 `raw_text` 的合法条件：只有 `kind=image`、`asset_path` 为包内真实存在的相对路径时才放行；`kind=text/table` 空 `raw_text` 是漏文告警，`asset_path` 与 `raw_text` 同时为空是硬失败。状态字段必须直接读取上游产出的原值。
3. 把 `PACKAGE_CONTRACT.md` 交给检索侧逐条确认；确认前不打正式 ZIP。双方保存逐字相同副本；只有字段语义或格式变化才升版本，文档勘误记录决策并同步副本但不升版本。
4. 双方封版前做联调冷启动：全新 AI + 两个 skill + 一本未处理 PDF，只给一句“用这两个 skill 把这本书洗完入库，然后查一个测试问题”。全程无需提问、结果带正确 citation 才通过；卡在交界处就补契约重测，同一处三轮不过则停机报告。

## 旧包升级为 contract_v2.1

1. 先找与锁定 PDF 同源的块级事实源，优先级为：现成 `book.md + pages.jsonl` → MinerU `content_list` → 重新 OCR。前两项存在时不得调用 OCR。
2. 在独立暂存目录运行主入口，不覆盖旧包：

```bash
python scripts/run_book.py --config <work>/book_config.json --pdf <work>/book.pdf --input-dir <block-source-dir> --output <staging-dir>
```

3. 程序重新生成章节地图和 `heading_path`。标题链只能来自原书块顺序、独立成行和层级关系；不能根据旧卡的前后位置或检索结果倒推。
4. 新旧逐卡比较 `raw_text`、`text`、citation、`text_sha256`。除 manifest 已登记的质量修正外，任一变化都先停止替换并报告。
5. 先运行切书侧 `validate.py`，再交检索侧 `validate_package.py`。两边都通过后才替换正式 ZIP；旧包保留为历史基线，不混入现役书单。

如果块级 `pages.jsonl` 已遗失，但旧包仍完整保留逐父段 `raw_text`、`source_block_ids` 和全量 coverage，可运行：

```bash
python scripts/rebuild_precontract.py --config <work>/book_config.json --source <旧包目录> --pdf <锁定PDF> --output <新暂存目录> --work-id <WORK_ID> --book-title "<BOOK_TITLE>" --pages <PDF页数>
```

该命令重新生成卡片、`heading_path`、状态字段、citation、验收和 ZIP，不复制旧卡、不调用 OCR。若旧格式没有保存丢弃块原文，manifest 必须登记“沿用已验收丢弃路由、未重新扫描丢弃原文”；不能把它写成全量丢弃内容复核。

## 五个硬门

1. PDF 页覆盖 100%。
2. 每个源块只有一个去向；`status=asset` 但 `asset_path` 为空或文件不存在，立即失败。
3. 保留正文异常 token 率低于 1%；丢弃块逐块按“纯文本长度至少 80＋英文词占比至少 35%”扫描，疑似误丢清单必须为 0。数字表走表格路由，星盘图只存资产。
4. 可检索卡不从句中间开始且不超过 1200 字。
5. 每条内容可回到书名、PDF 页码和页内段落；章/偈不确定时诚实写 `unknown`。

标准复现书固定为修正后的 K. N. Rao《Astrology, Destiny and the Wheel of Time》，`work_id=ASTROLOGY_DESTINY_WHEEL_OF_TIME`。WOT 与 Laghu 只能用于回归，不得用于最终陌生书冷启动考试。
