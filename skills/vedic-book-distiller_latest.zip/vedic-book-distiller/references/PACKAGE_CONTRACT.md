# contract_v2.1

`contract_v2.1` 是切书侧与检索侧之间唯一的成品包接口。

唯一事实源是切书 skill 内的 `references/PACKAGE_CONTRACT.md`；检索侧副本必须与它逐字相同，任一方不得单方面改字段。

正式 ZIP 的唯一根目录名必须等于 `manifest.work_id`。

## 1. 成品包文件清单

根目录必须包含以下文件：

- `manifest.json`
- `book.md`
- `pages.jsonl`
- `parents.jsonl`
- `source_cards.jsonl`
- `coverage.jsonl`
- `quality_gate_report.json`

存在资产引用时，ZIP 还必须包含每个 `asset_path` 指向的真实包内文件。

ZIP 根目录外不得存在任何文件。

旧字段包不属于本契约；`pre-contract`（契约前旧包）直接拒绝，不加兼容分支。

## 2. manifest.json

manifest 必须包含以下字段：

- `contract_version`
- `status`
- `work_id`
- `book_title`
- `book_version`
- `source_group`
- `case_study_heading_paths`
- `has_sloka`
- `has_sloka_detection`
- `source_pages`
- `source_pdf_sha256`
- `chapter_map`
- `counts`
- `quality`
- `ab_validation`
- `source_recovery`

`contract_version` 必须是 `contract_v2.1`。

`status` 必须是 `pass`。

`work_id`、`book_title`、`book_version`、`source_group` 必须是非空字符串。

`case_study_heading_paths` 必须是数组；每项是原书真实标题组成的非空字符串数组。没有案例区域也必须显式填写空数组 `[]`。卡片按标题路径前缀匹配其下属段落，不得按正文、人名、`you/your`、书名或页码猜测。

`has_sloka` 必须是布尔值，表示本书是否有偈号体系。

`has_sloka_detection.threshold_version` 必须是 `sloka_chain_v1`；`decision` 必须是布尔值且等于 `has_sloka`。`hit_count`、`eligible_paragraphs`、`longest_chain_count`、`longest_chain_span`、`max_marker`、`explicit_sloka_terms`、`half_or_range_hits` 必须是非负整数。

`source_pages` 必须是正整数。

`source_pdf_sha256` 必须是 64 位小写十六进制字符串。

`chapter_map` 每项必须有 `unit_id`、`chapter_title`、`chapter_number`、`pdf_pages`、`evidence_source`、`chapter_status`、`sloka_status`、`raw`、`normalized`、`transformations`。

`counts` 必须准确记录 `parents`、`source_cards`、`coverage_rows`、`source_blocks`。

`quality.page_coverage.status` 必须为 `pass`，且 `actual` 等于 `expected`。

`quality.text_anomaly` 必须使用 `plain_source_no_vowel_v1`，只统计纯正文、排除 HTML/表格；`rate` 必须低于 0.01，状态必须为 `pass`。

`quality.unknown_page_ratio` 不得大于 0.05。`quality.discard_misdrop` 必须记录固定方法 `plain_text_length_and_english_word_ratio_v1`、长度阈值 80、英文词占比阈值 0.35、扫描块数、疑似误丢条目和状态；疑似误丢清单为 0 才通过。

出包前必须运行包内同版 `scripts/check_gate.py` 的 G1-G3、G5、G6 入库质量门，并把完整结果写入 `quality_gate_report.json`。G1 段落卡占比必须不低于 20%；G2 可检索高置信 OCR 乱码率必须不高于 3%；G3 疑似误丢必须不高于源卡数 2%；G5 仍可检索的疑似版面家具卡不得高于可检索文本卡 3%；G6 可检索文本卡不得低于全部源卡 85%。任一失败不得生成正式 ZIP。乱码卡和已确认页面家具只改为 `indexable=false`，不得删除；低置信疑似项只写入报告的 `G2.review_candidates`，不得自动隔离。

`ab_validation.status` 必须为 `pass`，`ab_validation.undocumented_raw_changes` 必须为 0。

`source_recovery.undocumented_raw_changes` 必须为 0。

## 3. parents.jsonl

每行必须包含：

`parent_id`、`book_title`、`book_version`、`chapter_number`、`chapter_title`、`chapter_status`、`sloka`、`sloka_status`、`pdf_pages`、`pdf_page`、`page_block`、`source_block_ids`、`kind`、`heading_path`、`raw_text`、`normalized_text`、`transformations`、`asset_path`、`citation`。

`parent_id` 必须非空且全包唯一。

`source_block_ids` 必须是非空列表，且每个 `source_block_id` 全包唯一。

`kind` 只能是 `text`、`table`、`image`。

`heading_path` 必须是字符串数组，按原书层级从章标题排到最近的限定性标题；无法从版面结构确定时允许为空数组。内容只能来自原书真实标题块，不得改写、补写、翻译或由模型推断。

## 4. source_cards.jsonl

每行必须包含：

`card_id`、`parent_id`、`book_title`、`book_version`、`chapter_number`、`chapter_title`、`chapter_status`、`sloka`、`sloka_status`、`pdf_pages`、`pdf_page`、`page_block`、`kind`、`text_role`、`heading_path`、`is_case_study`、`text`、`raw_text`、`indexable`、`asset_path`、`citation`、`text_sha256`。

`card_id` 必须全包唯一；`parent_id` 必须指向已有父段。

禁止出现旧字段 `child_id` 和 `original_text`。

`kind` 只能是 `text`、`table_row`、`image`。

`text_role` 只能是 `source`、`derived_for_search`、`asset`。

`heading_path` 必须与所属父段逐字一致。检索侧可以把它作为搜索上下文，但不得拼进或改写 `text`、`raw_text`、`citation`。

`is_case_study` 必须是布尔值。卡片 `heading_path` 以 manifest 中任一 `case_study_heading_paths` 为前缀时必须为 `true`，其他卡片必须为 `false`；配置为空数组时，全书每张卡仍必须显式输出 `false`。

`text` 长度不得超过 1200 个字符；`text_sha256` 必须等于 UTF-8 `text` 的 SHA-256。

图片卡必须是 `kind=image`、`text_role=asset`、`indexable=false`，并有真实 `asset_path`。

## 5. 状态与空文本

`chapter_status` 只能是 `confirmed`、`unknown`。

`sloka_status` 只能是 `present`、`not_applicable`、`unknown`。

`sloka_status=present` 时，`sloka` 必须是非空字符串。

`sloka_status=not_applicable` 或 `unknown` 时，`sloka` 必须为 `null`。

`has_sloka=false` 时，所有父段和卡片都必须是 `sloka_status=not_applicable`。

图片父段允许 `raw_text` 为空，但必须有真实 `asset_path`；图片子卡必须不可检索。

`kind=text/table` 且 `raw_text` 为空属于漏文告警并验收失败。

`asset_path` 与 `raw_text` 同时为空属于硬失败。

## 6. coverage.jsonl

每行必须包含 `source_block_id`、`status`、`parent_id`、`card_ids`、`asset_path`、`reason`。

`status` 只能是 `retain_text`、`asset`、`discard`。

每个 `source_block_id` 只能出现一次，所有卡片必须被 coverage 路由覆盖。

`retain_text` 必须指向非图片父段，且 `reason` 为 null。普通正文的 `asset_path` 为 null；表格父段允许同时保留真实 `asset_path`，但其可检索性仍由 `source_cards.indexable` 表示，不新增 `asset+indexed` 状态。

`asset` 必须指向图片父段、真实资产和不可检索图片卡。

`discard` 必须没有 `parent_id`、`card_ids`、`asset_path`，且必须填写 `reason`。

## 7. citation

切书侧生成 citation，检索侧原样读取和返回，不重建、不改写、不继承上一卡。

citation 必须包含书名、版本、章节状态与标题、`Sloka` 标签和 PDF 页码。

偈号状态不是由空值猜测：`N/A [not_applicable]` 表示原书本来没有偈号，`unknown [unknown]` 表示应该有但尚未识别。

非 `present` 的 citation 还必须包含 `page_block`，保证无偈号内容仍可回查。

## 8. 检索侧读取边界

`books.json` 只保存 `work_id` 和 `package_zip`。

版本、同源组、包状态、`has_sloka`、`is_case_study`、状态字段和 citation 全部从 ZIP manifest/card 读取。

检索器不得从书名、正文、章号、偈号、上一卡、文件名或相似度推导这些字段。`is_case_study` 也不得按人名、`you/your` 或正文关键词推导。

## 9. quality_gate_report.json

报告必须包含 `gate_version`、`contract_version`、`work_id`、`counts`、`G1`、`G2`、`G3`、`G5`、`G6`、`warnings`、`verdict`。`gate_version` 必须为 `quality_gate_v2`，`contract_version` 必须为 `contract_v2.1`，`work_id` 必须等于 manifest；`verdict` 与 G1-G3、G5、G6 的 `status` 必须全部为 `pass`。`counts.source_cards` 必须等于实际卡数，`counts.indexable_text_cards` 与 `counts.nonindexable_text_cards` 必须与卡片逐张重算结果一致。G5 必须记录疑似版面家具卡数、归一化模式、实际页数和比例；G6 必须按 `counts.indexable_text_cards / counts.source_cards` 记录比例。

G2 必须同时保留 `auto_flagged` 和 `review_candidates`：前者是已被高置信规则设为不可检索的卡，后者只供解读层复核。G3 检查不可检索文本时，已经进入后续卡片 `heading_path` 的原书结构标题不算误丢。

## 10. 变更与联调

`contract_v2.1` 新增强制质量门报告；质量门现升级为 `quality_gate_v2`，要求出包前 G1-G3、G5、G6 全绿。此次只扩展质量报告与放行条件，不改变 manifest、父段、卡片或 coverage 字段，契约版本仍为 `contract_v2.1`。旧 `contract_v2` 包必须重建或确定性升级后才能再次交付。

双方各自冷启动通过后，使用全新 AI、两个 skill 和一本未处理 PDF，只给一句：“用这两个 skill 把这本书洗完入库，然后查一个测试问题。”

全程无需提问且返回带正确 citation 的结果才通过。

卡在交界处说明契约缺漏，补契约后重测；同一处连续三轮不过，停止并提交停机报告。
