# 通用冻结规则

## 开工先看：唯一环境与工具入口

- Codex 正式 Skill：`C:\Users\aa\.codex\skills\vedic-book-distiller`，界面名“MD工具 · 星占规则卡”。
- J 盘同步镜像：`J:\洗书工作区V2\skills\vedic-book-distiller`；只作交接副本，运行时仍以 C 盘正式版为准。
- MinerU 3.4.4 CUDA Python：`J:\mineru-3.4.4-cuda\Scripts\python.exe`。
- 显卡：NVIDIA RTX 3080 10GB；OCR 只许 CUDA，CUDA 不可用立即失败，不回退 CPU。
- 现役入口：`scripts\run_book.py`；切书验收：`scripts\validate.py`；出包质量门：`scripts\check_gate.py`；下游验包：`C:\Users\aa\.codex\skills\vedic-evidence-retrieval\scripts\validate_package.py`。
- 旧包确定性重建：`scripts\rebuild_precontract.py`；只用于仍保存逐父段原文、原始块号和全量 coverage 的已验收旧包，不调用 OCR，不复制旧卡。
- 暂存只放 `C:\Users\aa\Documents\ChatGPT\洗书\_staging_contract_v2_YYYYMMDD`；验收通过的最新版才进入 `J:\洗书成品库`。
- 打 Skill ZIP 时只收代码、配置、文档、示例和测试；`_test_run`、`__pycache__`、`.pyc` 和成品书包不得入包。正式 ZIP 从已与 C 盘源文件对齐的 J 盘镜像生成，避免把本机诊断材料带进去。

每次任务先读取本文件和 `..\SKILL.md`，只检查上述固定路径是否存在并执行一次 CUDA 探测；禁止扫描整个 C/D/E/J 盘、重复安装工具或从聊天记录猜路径。

CUDA 探测：

```text
J:\mineru-3.4.4-cuda\Scripts\python.exe -c "import torch; print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0))"
```

1. 输入 PDF 先锁路径、页数、SHA；只读检查，不复用旧 OCR 中间文件。
2. 先做前/中/后三页文字层体检；不合格才调用配置里的 MinerU CUDA OCR，禁止 CPU 回退。
3. 章节先全书扫描标题和（古籍适用时）偈号，再全局自检，最后统一回填；正文标题定边界，目录只核对章数。
4. `unknown` 是合法状态；无法可靠归章正文页超过 5% 才停止。章节异常只报警，不猜、不继承上一章。
5. 粘连标题只做确定性空格/大小写整理，`raw` 与 `normalized` 同时保存；不得 `I/1`、`O/0` 互换。
   OCR 把明确的连续编号列表粘成超长块时，程序只在连续 `(1)`、`(2)` 等项目边界插入换行并留 transformation；普通长句和单个超长项目仍失败，禁止从句中间硬切。
6. 五硬门：页覆盖 100%；源块唯一去向；asset 路径真实存在；保留正文异常 token <1% 且疑似误丢清单为 0；卡片可定位、不可从句中间开始且不超过 1200 字。
   MinerU 将 text 块误标为 header/footer 时，组装器沿用同一门槛：纯文本长度至少 80 且英文词占比至少 35% 的块回流正文；短页眉和非英文块仍丢弃。
7. 纯提速 A/B 要求 raw 零差异；质量修正允许登记差异，未登记差异必须为 0。短卡、unknown、软耗时只登记。
8. 限定性标题由程序按块顺序维护 `heading_path`：章节切换清空，同级标题替换，上级标题持续继承；标题文字只取原书，不用模型、不改写正文。
9. 旧包升 `contract_v2` 必须回到块级事实源重新组装；有 `book.md + pages.jsonl` 或 MinerU `content_list` 时不重跑 OCR，不从旧卡顺序猜标题链，不直接补字段冒充新包。
10. 只有块级事实源缺失、但逐父段原文与全量 coverage 仍在时，才运行 `rebuild_precontract.py`；若丢弃块原文已遗失，manifest 必须明写旧丢弃路由复用，不能写成重新扫描通过。
11. 每书配置必须显式有 `case_study_heading_paths`。生成器按 `heading_path` 前缀写 `is_case_study`；不根据正文、人名或代词猜，不在代码里写书名、页码或固定章节标题。验收器只做高精度漏登记检查：独立 Case Study/Case Summary 标题、recent reading/remarks 引导，以及标题区域前部明确引入的 horoscope of 人名；recent reading/remarks 后的连续兄弟标题也必须登记。单独 you/your、目录或理论段泛提不触发，漏项会列出 heading_path。
12. 同一 PDF 页出现多个章节标题时，页级证据无法区分，整段共同跨度统一标 `unknown`，不右移章节、不猜归属；章节地图必须保证每页恰好一个条目。
13. 没有 `CHAPTER`/`SECTION` 前缀的裸章节标题可在每书配置中声明 `chapter_title_sequence`：每项为 `{title, chapter_number}`，标题必须来自目录并在正文以独立块逐字出现；程序只按声明顺序取前一项之后的首次精确命中，缺失、倒退或同区间重复命中写入 `chapter_scan`，禁止模糊匹配、书名/页码特判或猜测。
14. 出包固定执行 `check_gate.py` 的 `quality_gate_v2`：G1 段落卡占比不低于 20%、G2 可检索高置信乱码不高于 3%、G3 疑似误丢不高于 2%、G5 仍可检索的疑似版面家具不高于 3%、G6 可检索文本卡占全部源卡不低于 85%。任一失败不打 ZIP。高置信乱码和已确认页面家具只设 `indexable=false`；疑似项只写 `quality_gate_report.json`，不自动处理。G6 必须读取完整书包，禁止用只含可检索卡的 SQLite 假算。
15. 文字层若是一行一个源块，配置 `merge_wrapped_lines=true` 后按句末与标题边界合成段落；跨页只在上页未完句、章节与标题链一致时续接。父段和 coverage 必须登记全部成员源块，原始各行保留在 `raw_text`。
16. 页面家具只按通用版面证据判断：限定每页首尾各两个短文本块，连续数字归一为 `#` 后，在至少 10% 页面且不少于 5 页重复才设为 `indexable=false`；不删除原文、不靠书名特判。结构标题与页面家具分别计数；正文重复定式和表格残渣不得冒充页面家具。
