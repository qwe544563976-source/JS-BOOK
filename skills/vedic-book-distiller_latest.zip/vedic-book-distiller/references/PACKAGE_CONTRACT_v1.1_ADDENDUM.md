# contract_v1.1 已废止增补

本文件仅保留历史记录；当前正式接口已由 `contract_v2` 取代，不得执行本增补。

本文件是现行 `contract_v1` 的待启用增补，不是当前生效契约。当前唯一生效接口仍是同目录的 `PACKAGE_CONTRACT.md`；本增补在下述生效条件全部满足前，不改变现行验包、入库和检索行为。

## 1. 唯一新增字段

`contract_v1.1` 相对 `contract_v1` 只新增一个字段名：`is_case_study`。

- `manifest.chapter_map` 的每一项必须新增 `is_case_study`，类型必须是布尔值。
- `source_cards.jsonl` 的每一行必须新增同名 `is_case_study`，类型必须是布尔值。
- 不修改 `text_role`；其合法值仍是 `source`、`derived_for_search`、`asset`。
- 不新增另一种案例状态、案例枚举或从正文推导的备用字段。

## 2. 上游标注规则

`manifest.chapter_map[*].is_case_study` 是章节级唯一事实源。每个章节必须由切书侧依据上游明确给出的章节归属，逐项标成 `true` 或 `false`；缺失、冲突或无法确定时硬失败，不得默认写 `false`。

`source_cards[*].is_case_study` 必须继承该卡唯一所属章节的值。卡片无法唯一归入一个 `chapter_map` 项，或卡片值与章节值不一致时，验包必须失败。

禁止检索侧或任何模型根据章名、正文、书名、文件名、相似度、第二人称 `you/your`、案例人物姓名或其他语言线索猜测 `is_case_study`。

## 3. 下游行为

检索侧只读取包内显式 `is_case_study`，不补值、不改写、不自行分类。

`is_case_study=true` 的内容只能作为案例背景或实例证据展示，不能被提升为通用规则、普遍判词，也不能单独作为面向其他命盘的通用结论依据。

## 4. 版本隔离与迁移

当前两本 `contract_v1` 成品包、当前 `books.json` 和当前索引全部冻结，继续作为现役书架使用。本增补待启用期间不修改现行 `PACKAGE_CONTRACT.md`、验证器、书包或索引。

所有现役书必须先在临时暂存区完成 `contract_v1.1` 重包和验收。任一本仍是 `contract_v1` 时，不得把 `contract_v1` 与 `contract_v1.1` 混合登记、混合建库或混合发布。

不要求维护第二套长期书架。允许使用临时暂存清单和临时索引完成验收；全部现役书通过后，再一次性整体切换现有书架。切换后的正式清单和正式索引只能包含 `contract_v1.1` 包。

## 5. 生效条件

只有以下条件全部满足，`contract_v1.1` 才能正式生效：

1. 切书侧与检索侧保存逐字相同的本增补，并完成签收。
2. 两侧验证器都改为强制要求 `contract_version=contract_v1.1`、章节和卡片的 `is_case_study` 为布尔值，并校验卡片与章节一致。
3. 全部现役书都已重包为 `contract_v1.1`，且正文、`raw_text`、`text` 与 citation 无未登记变化。
4. 全部新包分别通过切书侧和检索侧验包。
5. 固定回归、双方各自冷启动和双 skill 联调冷启动全部通过。
6. 正式切换时确认清单和索引中不存在任何 `contract_v1` 包或旧版卡片。

上述条件未全部满足时，继续运行冻结的 `contract_v1` 书架，不提前启用本增补。
