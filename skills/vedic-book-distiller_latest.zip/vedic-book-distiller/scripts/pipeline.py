#!/usr/bin/env python3
"""Minimal deterministic PDF->source-card pipeline; no model calls."""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import time
import zipfile
from pathlib import Path

try:
    from .check_gate import CONTRACT_VERSION, is_high_confidence_mush, load_package as load_gate_package, write_report as write_gate_report
except ImportError:
    from check_gate import CONTRACT_VERSION, is_high_confidence_mush, load_package as load_gate_package, write_report as write_gate_report


ROMAN = re.compile(r"^(?P<num>[IVXLCDM]+)$", re.I)
SECTION = re.compile(r"^SECTION\s+(?P<num>[IVXLCDM]+(?:[- ]?[A-Z])?)(?:\s+(?P<title>.*))?$", re.I)
CHAPTER = re.compile(r"^.{0,24}?\b(?:CHAPTER|ADHYAYA)\s+(?P<num>[IVXLCDM]+|\d+)(?![A-Za-z0-9])(?P<rest>.*)$", re.I)
CHAPTER_END = re.compile(
    r"(?:\bEnd of (?:the )?(?P<num>\d+)(?:st|nd|rd|th)?\s+(?:Chapter|Adhyaya)\b|"
    r"\bends the (?P<num_ord>\d+)(?:st|nd|rd|th)?\s+Adhyaya\b|"
    r"\bends the (?P<num_word>first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|"
    r"eleventh|twelfth|thirteenth|fourteenth|fifteenth|sixteenth|seventeenth|eighteenth|nineteenth|"
    r"twentieth|twenty[- ]first|twenty[- ]second|twenty[- ]third|twenty[- ]fourth|twenty[- ]fifth|"
    r"twenty[- ]sixth|twenty[- ]seventh|twenty[- ]eighth)\s+(?:Chapter|Adhyaya)\b)",
    re.I,
)

ORDINAL_WORD_NUMBERS = {
    "first": 1, "second": 2, "third": 3, "fourth": 4, "fifth": 5,
    "sixth": 6, "seventh": 7, "eighth": 8, "ninth": 9, "tenth": 10,
    "eleventh": 11, "twelfth": 12, "thirteenth": 13, "fourteenth": 14,
    "fifteenth": 15, "sixteenth": 16, "seventeenth": 17, "eighteenth": 18,
    "nineteenth": 19, "twentieth": 20, "twenty first": 21, "twenty-second": 22,
    "twenty second": 22, "twenty-third": 23, "twenty third": 23,
    "twenty-fourth": 24, "twenty fourth": 24, "twenty-fifth": 25,
    "twenty fifth": 25, "twenty-sixth": 26, "twenty sixth": 26,
    "twenty-seventh": 27, "twenty seventh": 27, "twenty-eighth": 28,
    "twenty eighth": 28,
}


def chapter_end_number(match: re.Match[str]) -> int | None:
    if match.group("num"):
        return int(match.group("num"))
    if match.group("num_ord"):
        return int(match.group("num_ord"))
    word = " ".join(match.group("num_word").lower().replace("-", " ").split())
    return ORDINAL_WORD_NUMBERS.get(word)
CHECKLIST = re.compile(r"^CHECKLIST\s*-?\s*(?P<num>[IVXLCDM]+)?\s*(?P<title>.*)$", re.I)
APPENDIX = re.compile(r"^APPENDIX\s+(?P<num>[IVXLCDM]+)(?:\s+(?P<title>.*))?$", re.I)
PAGE_MARK = re.compile(r"^<!--\s*SOURCE_PAGE\s+(\d+)\s*-->$")
SLOKA_MARKER = re.compile(
    r"^\s*(?:(?P<label>slokas?|verses?)\s+)?(?P<start>\d+)"
    r"(?:\s*[-–—]\s*(?P<end>\d+)(?P<range_half>½|[ \t]*1/2)?)?"
    r"(?P<single_half>½|[ \t]*1/2)?\s*[.):]?\s+",
    re.I,
)
SLOKA_TERM = re.compile(r"\b(?:slokas?|verses?)\b", re.I)
SLOKA_DETECTION_VERSION = "sloka_chain_v1"
NO_VOWEL_ALLOW = {"by", "why", "sky", "try", "dry", "fly", "dr", "mrs", "yrs", "th", "nd", "rd", "st", "rhythm", "myth"}
HEADING_CONNECTORS = {"a", "an", "and", "as", "at", "by", "for", "from", "in", "of", "on", "or", "the", "to", "with"}
STRUCTURAL_HEADING = re.compile(r"^(?:CHAPTER|ADHYAYA|SECTION|APPENDIX|CHECKLIST)\b", re.I)


def normalize_case_study_heading_paths(value: object) -> list[list[str]]:
    """Validate the explicit per-book case-study heading paths."""
    if not isinstance(value, list):
        raise ValueError("case_study_heading_paths 必须是数组，未发现案例时也要显式填写 []")
    result: list[list[str]] = []
    for index, path in enumerate(value):
        if not isinstance(path, list) or not path or not all(isinstance(item, str) and item.strip() for item in path):
            raise ValueError(f"case_study_heading_paths[{index}] 必须是非空字符串数组")
        result.append(list(path))
    return result


def case_study_for_heading_path(heading_path: list[str], declared_paths: list[list[str]]) -> bool:
    """Return true only when an explicit source heading path is a prefix."""
    return any(heading_path[: len(path)] == path for path in declared_paths)


_CASE_HEADING_CUE = re.compile(r"^(?:case\s+study\b.*|case\s+summary\b.*|case\s+two)$", re.I)
_RECENT_READING_CUE = re.compile(r"\brecent\s+reading\s+i\s+gave\b", re.I)
_REMARKS_CUE = re.compile(r"\bplease\s+write\s+your\s+remarks\b", re.I)
_HOROSCOPE_OF_CUE = re.compile(r"\b(?:the\s+)?horoscope\s+of\s+(?:['\"](?P<quoted>[^'\"]{1,80})['\"]|(?P<plain>[^,.;:\n]{1,80}))", re.I)
_HOROSCOPE_INTRO = re.compile(r"(?:let\s+me\s+(?:give|show|illustrate|present)|given\s+here\s+is|shown\s+by\s+taking\s+up|taking\s+up|examin(?:e|ing)|present(?:ing)?|illustrat(?:e|ing|ed))", re.I)
_GENERIC_HOROSCOPE_SUBJECTS = {
    "a horoscope", "the horoscope", "this horoscope", "your horoscope", "our horoscope",
    "his horoscope", "her horoscope", "their horoscope", "which horoscope", "what horoscope",
    "a person", "the person", "a case", "the case", "astrology", "planets", "children",
}


def _case_study_cue(card: dict) -> tuple[str, str] | None:
    """Return a high-confidence case cue without using generic you/your text."""
    path = card.get("heading_path") if isinstance(card.get("heading_path"), list) else []
    values = [" ".join(str(value).split()) for value in path if isinstance(value, str) and value.strip()]
    text = " ".join(str(card.get("text") or card.get("raw_text") or "").split())
    if values:
        last = values[-1]
        if _CASE_HEADING_CUE.fullmatch(last) and text.casefold() == last.casefold():
            return "explicit_case_heading", last
    for pattern, reason in ((_RECENT_READING_CUE, "recent_reading"), (_REMARKS_CUE, "remarks_request")):
        match = pattern.search(text)
        if match:
            return reason, match.group(0)
    match = _HOROSCOPE_OF_CUE.search(text)
    if match:
        prefix = text[max(0, match.start() - 100) : match.start()]
        if not _HOROSCOPE_INTRO.search(prefix):
            return None
        subject = match.group("quoted") or match.group("plain") or ""
        subject = " ".join(subject.split()).strip(" '\"“”‘’")
        subject = re.sub(r"^(?:a|an|the)\s+", "", subject, flags=re.I)
        if subject and subject.casefold() not in _GENERIC_HOROSCOPE_SUBJECTS and not re.match(r"^(?:your|our|their|which|what|this|that)\b", subject, re.I):
            return "named_horoscope", match.group(0)
    return None


def case_study_config_gaps(cards: list[dict], declared_paths: list[list[str]]) -> list[dict]:
    """Find explicit case starts whose heading path was not declared.

    Once a high-confidence cue starts under a parent heading, immediate sibling
    headings that follow it in the same parent are checked as part of the same
    continuous case region. This only reports gaps; it never changes card flags.
    """
    declared = normalize_case_study_heading_paths(declared_paths)
    gaps: list[dict] = []
    seen: set[tuple[str, tuple[str, ...]]] = set()

    def add(path: list[str], reason: str, card: dict, trigger: str) -> None:
        clean = [" ".join(str(value).split()) for value in path if isinstance(value, str) and value.strip()]
        key = (reason, tuple(clean))
        if not clean or key in seen or case_study_for_heading_path(clean, declared):
            return
        seen.add(key)
        gaps.append({"heading_path": clean, "reason": reason, "trigger": trigger, "card_id": card.get("card_id") or card.get("page_block")})

    for index, card in enumerate(cards):
        path = card.get("heading_path") if isinstance(card.get("heading_path"), list) else []
        path = [" ".join(str(value).split()) for value in path if isinstance(value, str) and value.strip()]
        cue = _case_study_cue(card)
        if not cue or not path:
            continue
        reason, trigger = cue
        if reason == "named_horoscope":
            # A named horoscope is a case-region cue only when it opens the
            # local heading. Embedded examples in a long theory section do not
            # justify marking the entire section as a case.
            first_in_path = next((position for position, row in enumerate(cards) if row.get("heading_path") == path), index)
            if index - first_in_path > 2 or (path and str(path[0]).casefold().startswith("appendix")):
                continue
        if not case_study_for_heading_path(path, declared):
            add(path, "explicit_case_cue" if reason != "explicit_case_heading" else "explicit_case_heading", card, trigger)

        # Sibling continuity is only meaningful beneath a real parent path.
        parent = path[:-1]
        if not parent:
            continue
        if reason in {"explicit_case_heading", "named_horoscope"}:
            continue
        seen_siblings: set[tuple[str, ...]] = {tuple(path)}
        for later in cards[index + 1 :]:
            later_path = later.get("heading_path") if isinstance(later.get("heading_path"), list) else []
            later_path = [" ".join(str(value).split()) for value in later_path if isinstance(value, str) and value.strip()]
            if later_path[: len(parent)] != parent or len(later_path) <= len(parent):
                break
            if len(later_path) != len(parent) + 1:
                continue
            sibling = tuple(later_path)
            if sibling in seen_siblings:
                continue
            seen_siblings.add(sibling)
            add(later_path, "continuous_case_sibling", later, trigger)
    return gaps


def citation(row: dict) -> str:
    pages = row["pdf_pages"]
    page_part = f"PDF page {pages[0]}" if len(pages) == 1 else f"PDF pages {pages[0]}-{pages[-1]}"
    sloka_status = row["sloka_status"]
    sloka = row.get("sloka") if sloka_status == "present" else None
    label = str(sloka) if sloka is not None else ("N/A" if sloka_status == "not_applicable" else "unknown")
    value = f"{row['book_title']} · {row['book_version']} · {row['chapter_status']}: {row['chapter_title']} · Sloka {label} [{sloka_status}] · {page_part}"
    if sloka_status != "present":
        value += f" · page_block {row['page_block']}"
    return value


def detect_has_sloka(book_md: Path) -> dict:
    """用固定偈号链规则确定书级 has_sloka；不接受人工覆盖。"""
    text = book_md.read_text(encoding="utf-8")
    paragraphs = [
        re.sub(r"\s+", " ", part).strip()
        for part in re.split(r"\n\s*\n", text)
        if part.strip() and not part.lstrip().startswith("<!-- SOURCE_PAGE")
    ]
    hits: list[tuple[int, int, bool, bool]] = []
    for paragraph in paragraphs:
        match = SLOKA_MARKER.match(paragraph)
        if not match:
            continue
        start = int(match.group("start"))
        end = int(match.group("end") or start)
        if start > 500 or end > 500:
            continue
        hits.append((start, end, bool(match.group("range_half") or match.group("single_half")), bool(match.group("label"))))

    best: list[tuple[int, int, bool, bool]] = []
    for index, first in enumerate(hits):
        chain = [first]
        low, high = first[0], first[1]
        for item in hits[index + 1 :]:
            start, end = item[0], item[1]
            if start < low:
                break
            if start < high - 1:
                continue
            if start <= high + 5:
                chain.append(item)
                high = max(high, end)
            else:
                break
        old_span = best[-1][1] - best[0][0] + 1 if best else 0
        new_span = chain[-1][1] - chain[0][0] + 1
        if (new_span, len(chain)) > (old_span, len(best)):
            best = chain

    chain_span = best[-1][1] - best[0][0] + 1 if best else 0
    explicit_terms = len(SLOKA_TERM.findall(text))
    half_or_range_hits = sum(start != end or half for start, end, half, _ in hits)
    strong_true = (
        (chain_span >= 30 and len(best) >= 15)
        or (explicit_terms >= 3 and chain_span >= 10)
        or (half_or_range_hits >= 3 and chain_span >= 10)
    )
    decision = bool(strong_true)
    return {
        "threshold_version": SLOKA_DETECTION_VERSION,
        "decision": decision,
        "hit_count": len(hits),
        "eligible_paragraphs": len(paragraphs),
        "ratio": round(len(hits) / max(1, len(paragraphs)), 6),
        "longest_chain_count": len(best),
        "longest_chain_span": chain_span,
        "max_marker": max((end for _, end, _, _ in hits), default=0),
        "explicit_sloka_terms": explicit_terms,
        "half_or_range_hits": half_or_range_hits,
    }


def first_sloka(text: str) -> str | None:
    for line in text.splitlines():
        match = SLOKA_MARKER.match(line.strip())
        if match:
            start = match.group("start")
            end = match.group("end")
            half = match.group("range_half") or match.group("single_half") or ""
            return f"{start}-{end}{half}" if end else f"{start}{half}"
    return None


def discard_misdrop_report(blocks: list[dict]) -> dict:
    """按固定阈值检查实际丢弃块，疑似误丢条目非空即失败。"""
    suspicious: list[dict] = []
    for block in blocks:
        text = str(block.get("text") or block.get("raw_text") or "").strip()
        words = re.findall(r"\b[\w]+\b", text, re.UNICODE)
        english_words = re.findall(r"\b[A-Za-z]+\b", text)
        ratio = len(english_words) / max(1, len(words))
        if len(text) >= 80 and ratio >= 0.35:
            suspicious.append({
                "source_block_id": block.get("source_block_id"),
                "pdf_page": block.get("pdf_page"),
                "length": len(text),
                "english_word_ratio": round(ratio, 6),
            })
    return {
        "method": "plain_text_length_and_english_word_ratio_v1",
        "length_threshold": 80,
        "english_word_ratio_threshold": 0.35,
        "scanned_blocks": len(blocks),
        "items": suspicious,
        "count": len(suspicious),
        "status": "pass" if not suspicious else "fail",
    }


def text_anomaly_report(texts: list[str]) -> dict:
    """只统计纯正文英文词；HTML 和表格不进入分母。"""
    checked = bad = 0
    examples: list[str] = []
    for text in texts:
        for word in re.findall(r"\b[A-Za-z]+\b", text):
            lower = word.lower()
            checked += 1
            if len(lower) >= 3 and not re.search(r"[aeiou]", lower) and lower not in NO_VOWEL_ALLOW and not ROMAN.fullmatch(word):
                bad += 1
                if len(examples) < 20:
                    examples.append(word)
    rate = bad / checked if checked else 0.0
    return {"method": "plain_source_no_vowel_v1", "bad_tokens": bad, "checked_tokens": checked, "rate": round(rate, 6), "limit": 0.01, "examples": examples, "status": "pass" if rate < 0.01 else "fail"}


_ENUM_ITEM_MARKER = re.compile(r",\s+\((?P<number>\d{1,2})\)")


def _split_numbered_list_unit(text: str) -> str | None:
    """Insert only whitespace at clear consecutive parenthesized item boundaries."""
    matches = list(_ENUM_ITEM_MARKER.finditer(text))
    if len(matches) < 2:
        return None
    numbers = [int(match.group("number")) for match in matches]
    consecutive = any(right == left + 1 for left, right in zip(numbers, numbers[1:]))
    if not consecutive:
        return None
    return _ENUM_ITEM_MARKER.sub(lambda match: ",\n(" + match.group("number") + ")", text)


def sentence_chunks(text: str, limit: int = 1200) -> list[str]:
    text = text.strip()
    if not text:
        return []
    if len(text) <= limit:
        return [text]
    units = [part.strip() for part in re.split(r"(?<=[.!?;:])\s+|\n+", text) if part.strip()]
    if any(len(unit) > limit for unit in units):
        repaired = _split_numbered_list_unit(text)
        if repaired is not None:
            units = [part.strip() for part in re.split(r"(?<=[.!?;:])\s+|\n+", repaired) if part.strip()]
    if any(len(unit) > limit for unit in units):
        raise ValueError("单句超过 1200 字，拒绝从句中间硬切")
    chunks: list[str] = []
    current = ""
    for unit in units:
        candidate = f"{current} {unit}".strip()
        if current and len(candidate) > limit:
            chunks.append(current)
            current = unit
        else:
            current = candidate
    if current:
        chunks.append(current)
    return chunks


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def roman_value(value: str) -> int | None:
    value = value.upper()
    if value.isdigit():
        return int(value)
    if not ROMAN.fullmatch(value):
        return None
    total, prev = 0, 0
    for char in reversed(value):
        n = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}[char]
        total += -n if n < prev else n
        prev = n
    return total


def normalize_heading(raw: str) -> tuple[str, list[dict]]:
    """Only whitespace/case normalization; never maps I/1 or O/0."""
    text = " ".join(raw.strip().split())
    changes: list[dict] = []
    match = CHAPTER.match(text)
    if match:
        rest = match.group("rest")
        if rest and not rest.startswith(" "):
            fixed = f"CHAPTER {match.group('num')} {rest}"
            changes.append({"kind": "insert_space_after_roman", "raw": text, "normalized": fixed})
            text = fixed
    upper_prefix = text.upper()
    if upper_prefix.startswith(("SECTION ", "CHAPTER ", "CHECKLIST", "APPENDIX ")) and text != upper_prefix:
        # Keep title letters intact; normalize only the structural keyword.
        keyword = upper_prefix.split()[0]
        text = keyword + text[len(keyword):]
    return text, changes


def heading_level(block: dict) -> int | None:
    """Return a deterministic layout heading level, or None for ordinary content."""
    if str(block.get("route") or "retain_text") == "discard" or str(block.get("kind") or "text") != "text":
        return None
    text = " ".join(str(block.get("normalized_text") or block.get("raw_text") or "").split())
    if not text or len(text) > 160 or len(text.split()) > 18:
        return None
    if STRUCTURAL_HEADING.match(text):
        return 0
    letters = re.sub(r"[^A-Za-z]+", "", text)
    if not letters:
        return None
    if letters == letters.upper() and len(letters) >= 4:
        return 1
    if text.endswith((".", "?", "!", ";")):
        return None
    words = re.findall(r"[A-Za-z][A-Za-z'’\-]*", text)
    content_words = [word for word in words if word.lower() not in HEADING_CONNECTORS]
    if content_words and all(word[0].isupper() for word in content_words):
        return 2
    if text.endswith(":") and len(words) <= 10:
        return 3
    return None


def _base_heading_path(entry: dict) -> list[str]:
    values: list[str] = []
    raw = " ".join(str(entry.get("raw") or "").split())
    title = " ".join(str(entry.get("chapter_title") or "").split())
    if raw:
        values.append(raw)
    if title and title.lower() not in {"front matter", "unknown"} and title.lower() not in raw.lower():
        values.append(title)
    return list(dict.fromkeys(values))


def heading_paths_for_rows(page_rows: list[dict], chapter_map: list[dict], ignored_heading_ids: set[str] | None = None) -> tuple[dict[str, list[str]], dict]:
    """Build heading inheritance from source block order; never infer or rewrite source text."""
    result: dict[str, list[str]] = {}
    active_unit: str | None = None
    base: list[str] = []
    local: list[tuple[int, str]] = []
    heading_blocks = content_blocks = 0
    ignored_heading_ids = ignored_heading_ids or set()
    for page_row in sorted(page_rows, key=lambda row: int(row.get("pdf_page", 0))):
        page = int(page_row.get("pdf_page", 0))
        entry = assign_entry(chapter_map, page)
        unit = str(entry.get("unit_id") or f"unknown:{page}")
        if unit != active_unit:
            active_unit = unit
            base = _base_heading_path(entry)
            local = []
        blocks = page_row.get("blocks")
        if not isinstance(blocks, list):
            continue
        for block in blocks:
            source_id = str(block.get("source_block_id") or "")
            if not source_id or str(block.get("route") or "retain_text") == "discard":
                continue
            level = None if source_id in ignored_heading_ids else heading_level(block)
            if level is not None:
                text = " ".join(str(block.get("raw_text") or block.get("normalized_text") or "").split())
                while local and local[-1][0] >= level:
                    local.pop()
                if text and text not in base:
                    local.append((level, text))
                heading_blocks += 1
            else:
                content_blocks += 1
            result[source_id] = list(dict.fromkeys(base + [text for _, text in local]))
    return result, {"method": "deterministic_heading_stack_v1", "heading_blocks": heading_blocks, "content_blocks": content_blocks}


def running_header_source_ids(page_rows: list[dict]) -> set[str]:
    """Find repeated first/last-page lines so they do not break paragraph merging."""
    candidates: dict[str, list[tuple[int, str]]] = {}
    for page_row in page_rows:
        page = int(page_row.get("pdf_page", 0))
        blocks = page_row.get("blocks") if isinstance(page_row.get("blocks"), list) else []
        edge = blocks[:2] + blocks[-2:]
        for block in edge:
            if block.get("route", "retain_text") != "retain_text" or block.get("kind", "text") != "text":
                continue
            text = " ".join(str(block.get("normalized_text") or block.get("raw_text") or "").split())
            normalized = re.sub(r"\b\d+\b", "", text)
            normalized = " ".join(re.sub(r"[^A-Za-z ]+", " ", normalized).lower().split())
            if 8 <= len(normalized) <= 100 and sum(char.isalpha() for char in normalized) / max(len(normalized), 1) >= 0.60:
                candidates.setdefault(normalized, []).append((page, str(block.get("source_block_id") or "")))
    result: set[str] = set()
    for occurrences in candidates.values():
        if len({page for page, _ in occurrences}) >= 3:
            result.update(source_id for _, source_id in occurrences if source_id)
    return result


def page_furniture_source_ids(page_rows: list[dict]) -> set[str]:
    """Find short page-edge patterns repeated on at least 10% of pages."""
    candidates: dict[str, list[tuple[int, str]]] = {}
    page_count = len({int(row.get("pdf_page", 0)) for row in page_rows if int(row.get("pdf_page", 0)) > 0})
    minimum_pages = min(page_count, max(5, (page_count + 9) // 10)) if page_count else 0
    for page_row in page_rows:
        page = int(page_row.get("pdf_page", 0))
        blocks = page_row.get("blocks") if isinstance(page_row.get("blocks"), list) else []
        for block in blocks[:2] + blocks[-2:]:
            if block.get("route", "retain_text") != "retain_text" or block.get("kind", "text") != "text":
                continue
            text = " ".join(str(block.get("normalized_text") or block.get("raw_text") or "").split())
            normalized = " ".join(re.sub(r"\d+", "#", text).casefold().split())
            if 1 <= len(text) <= 80 and sum(char.isalpha() for char in normalized) / max(len(normalized), 1) >= 0.60:
                candidates.setdefault(normalized, []).append((page, str(block.get("source_block_id") or "")))
    result: set[str] = set()
    for occurrences in candidates.values():
        if minimum_pages and len({page for page, _ in occurrences}) >= minimum_pages:
            result.update(source_id for _, source_id in occurrences if source_id)
    return result


def _paragraph_line_ends(text: str) -> bool:
    return re.search(r"[.!?:][\"'’”\)\]]*$", text.strip()) is not None


def _table_like_text_line(text: str) -> bool:
    words = re.findall(r"[A-Za-z]+", text)
    planet_codes = {"su", "mo", "ma", "me", "ju", "ve", "sa", "ra", "ke", "sun", "moon", "mars", "mer", "jup", "ven", "sat", "rah", "ket"}
    digits = sum(char.isdigit() for char in text)
    return (
        (digits >= 5 and digits / max(len(text), 1) >= 0.12)
        or sum(word.lower() in planet_codes for word in words) >= 3
        or (len(words) <= 8 and len(re.findall(r"\b\d{1,3}\b", text)) >= 4)
    )


def source_units(page_rows: list[dict], chapter_map: list[dict], heading_paths: dict[str, list[str]], merge_wrapped_lines: bool, body_start_page: int, running_headers: set[str]) -> list[dict]:
    """Return source units; optional mode joins line-layer prose into real paragraphs."""
    units: list[dict] = []
    current: dict | None = None

    def emit() -> None:
        nonlocal current
        if current is not None:
            if len(current["source_block_ids"]) > 1:
                current["transformations"].append({"kind": "merge_wrapped_lines", "source_block_ids": list(current["source_block_ids"])})
            units.append(current)
            current = None

    for page_row in sorted(page_rows, key=lambda row: int(row.get("pdf_page", 0))):
        page = int(page_row.get("pdf_page", 0))
        entry = assign_entry(chapter_map, page)
        blocks = page_row.get("blocks") if isinstance(page_row.get("blocks"), list) else []
        for block in blocks:
            source_id = str(block.get("source_block_id") or "")
            route = str(block.get("route") or "retain_text")
            kind = str(block.get("kind") or "text")
            raw = str(block.get("raw_text") or "")
            normalized = str(block.get("normalized_text") or raw)
            heading_path = heading_paths.get(source_id, [])
            can_merge = bool(
                merge_wrapped_lines
                and page >= body_start_page
                and route == "retain_text"
                and kind == "text"
                and source_id not in running_headers
                and heading_level(block) is None
                and not is_high_confidence_mush(normalized)
                and not _table_like_text_line(normalized)
            )
            if not can_merge:
                if source_id in running_headers and current is not None and not _paragraph_line_ends(current["normalized_text"]):
                    units.append({"entry": entry, "pdf_pages": [page], "page_block": source_id, "source_block_ids": [source_id], "route": route, "kind": kind, "raw_text": raw, "normalized_text": normalized, "transformations": list(block.get("transformations") or []), "asset_path": block.get("asset_path"), "reason": block.get("reason"), "table_rows": list(block.get("table_rows") or []), "heading_path": heading_path, "blocks": [block]})
                    continue
                emit()
                units.append({"entry": entry, "pdf_pages": [page], "page_block": source_id, "source_block_ids": [source_id], "route": route, "kind": kind, "raw_text": raw, "normalized_text": normalized, "transformations": list(block.get("transformations") or []), "asset_path": block.get("asset_path"), "reason": block.get("reason"), "table_rows": list(block.get("table_rows") or []), "heading_path": heading_path, "blocks": [block]})
                continue

            key = (entry.get("unit_id"), tuple(heading_path))
            if current is not None and current["merge_key"] != key:
                emit()
            if current is None:
                current = {"entry": entry, "pdf_pages": [page], "page_block": source_id, "source_block_ids": [source_id], "route": route, "kind": kind, "raw_text": raw, "normalized_text": normalized, "transformations": list(block.get("transformations") or []), "asset_path": None, "reason": None, "table_rows": [], "heading_path": heading_path, "blocks": [block], "merge_key": key}
            else:
                if page not in current["pdf_pages"]:
                    current["pdf_pages"].append(page)
                current["source_block_ids"].append(source_id)
                current["raw_text"] += "\n" + raw
                current["normalized_text"] += " " + normalized
                current["transformations"].extend(block.get("transformations") or [])
                current["blocks"].append(block)
            if _paragraph_line_ends(normalized):
                emit()
    emit()
    for unit in units:
        unit.pop("merge_key", None)
    return units


def parse_pages(book_md: Path) -> tuple[dict[int, list[str]], int]:
    pages: dict[int, list[str]] = {}
    page = 1
    for line in book_md.read_text(encoding="utf-8").splitlines():
        marker = PAGE_MARK.match(line.strip())
        if marker:
            page = int(marker.group(1))
            pages.setdefault(page, [])
        else:
            pages.setdefault(page, []).append(line)
    return pages, max(pages or {1: []})


def _title_after(lines: list[tuple[int, str]], index: int, fallback: str = "") -> str:
    for _, value in lines[index + 1 : index + 8]:
        value = value.strip()
        if not value or PAGE_MARK.match(value):
            continue
        if SECTION.match(value) or CHAPTER.match(value) or CHECKLIST.match(value) or APPENDIX.match(value):
            break
        return value
    return fallback


def _chapter_title_after(lines: list[tuple[int, str]], index: int, number: int) -> str:
    candidate = _title_after(lines, index)
    letters = re.sub(r"[^A-Za-z]+", "", candidate)
    return candidate if candidate and len(candidate) <= 180 and letters and letters == letters.upper() else f"Chapter {number}"


def normalize_chapter_title_sequence(value: object) -> list[dict]:
    """Validate optional bare-title chapter declarations without guessing."""
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError("chapter_title_sequence 必须是数组")
    result: list[dict] = []
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            raise ValueError(f"chapter_title_sequence[{index}] 必须是对象")
        title = item.get("title")
        number = item.get("chapter_number")
        if not isinstance(title, str) or not title.strip():
            raise ValueError(f"chapter_title_sequence[{index}].title 必须是非空字符串")
        if isinstance(number, bool) or (number is not None and (not isinstance(number, int) or number <= 0)):
            raise ValueError(f"chapter_title_sequence[{index}].chapter_number 必须是正整数或 null")
        result.append({"title": " ".join(title.split()), "chapter_number": number})
    return result


def _standalone_title_match(lines: list[tuple[int, str]], index: int, title: str) -> bool:
    """A configured title must occupy its own source block/line."""
    if " ".join(lines[index][1].split()) != title:
        return False
    previous = lines[index - 1][1].strip() if index else ""
    following = lines[index + 1][1].strip() if index + 1 < len(lines) else ""
    return not previous or not following or PAGE_MARK.match(previous) is not None or PAGE_MARK.match(following) is not None


def _configured_title_entries(lines: list[tuple[int, str]], body_start_page: int, sequence: list[dict]) -> tuple[list[dict], dict]:
    """Find declared bare chapter titles in order, reporting evidence gaps."""
    if not sequence:
        return [], {"declared": [], "hits": [], "missing": [], "order_backtracks": [], "ambiguities": []}
    matches: list[list[int]] = []
    for item in sequence:
        matches.append([
            index for index in range(len(lines))
            if lines[index][0] >= body_start_page and _standalone_title_match(lines, index, item["title"])
        ])
    entries: list[dict] = []
    hits_report: list[dict] = []
    missing: list[dict] = []
    order_backtracks: list[dict] = []
    ambiguities: list[dict] = []
    cursor = -1
    for index, item in enumerate(sequence):
        candidates = [position for position in matches[index] if position > cursor]
        if not candidates:
            reason = "order_backtrack" if matches[index] else "missing"
            report = {"title": item["title"], "chapter_number": item["chapter_number"], "reason": reason}
            (order_backtracks if reason == "order_backtrack" else missing).append(report)
            continue
        chosen = candidates[0]
        next_candidates = [position for position in matches[index + 1] if position > chosen] if index + 1 < len(sequence) else []
        boundary = next_candidates[0] if next_candidates else len(lines)
        extras = [position for position in candidates[1:] if position < boundary]
        if extras:
            ambiguities.append({
                "title": item["title"],
                "chosen_pdf_page": lines[chosen][0],
                "other_pdf_pages": [lines[position][0] for position in extras],
            })
        raw = lines[chosen][1]
        evidence = {"title": item["title"], "chapter_number": item["chapter_number"], "pdf_page": lines[chosen][0]}
        hits_report.append(evidence)
        entries.append({
            "kind": "chapter" if item["chapter_number"] is not None else "appendix",
            "page": lines[chosen][0],
            "raw": raw,
            "normalized": normalize_heading(raw)[0],
            "title": item["title"],
            "chapter_number": item["chapter_number"],
            "section": None,
            "changes": [],
            "evidence_source": ["configured_title_sequence"],
            "sequence_index": index,
        })
        cursor = chosen
    return entries, {
        "declared": sequence,
        "hits": hits_report,
        "missing": missing,
        "order_backtracks": order_backtracks,
        "ambiguities": ambiguities,
    }


def scan_chapters(book_md: Path, body_start_page: int = 6, chapter_title_sequence: object = None) -> tuple[list[dict], dict]:
    configured_sequence = normalize_chapter_title_sequence(chapter_title_sequence)
    allowed_chapter_numbers = {
        int(item["chapter_number"])
        for item in configured_sequence
        if item.get("chapter_number") is not None
    }
    lines: list[tuple[int, str]] = []
    page = 1
    for raw in book_md.read_text(encoding="utf-8").splitlines():
        marker = PAGE_MARK.match(raw.strip())
        if marker:
            page = int(marker.group(1))
        lines.append((page, raw.strip()))
    entries: list[dict] = []
    seen_chapters: set[tuple[object, int]] = set()
    current_section: dict | None = None
    for i, (page, raw) in enumerate(lines):
        if page < body_start_page or not raw:
            continue
        normalized, changes = normalize_heading(raw)
        sm = SECTION.match(normalized)
        if sm:
            number = sm.group("num").replace(" ", "-").upper()
            title = (sm.group("title") or "").strip()
            current_section = {"section_number": number, "section_title": title or f"Section {number}", "page": page}
            entries.append({"kind": "section", "page": page, "raw": raw, "normalized": normalized, "title": title or f"Section {number}", "section": current_section.copy(), "changes": changes})
            continue
        cm = CHAPTER.match(normalized)
        if cm:
            num = roman_value(cm.group("num"))
            if allowed_chapter_numbers and num not in allowed_chapter_numbers:
                continue
            chapter_key = ((current_section or {}).get("section_number"), num)
            if chapter_key in seen_chapters:
                continue
            seen_chapters.add(chapter_key)
            title = cm.group("rest").strip()
            if not title:
                title = _chapter_title_after(lines, i, num)
            title = " ".join(title.split())
            entries.append({"kind": "chapter", "page": page, "raw": raw, "normalized": normalized, "title": title, "chapter_number": num, "section": current_section.copy() if current_section else None, "changes": changes, "evidence_source": ["title"]})
            continue
        lm = CHECKLIST.match(normalized)
        if lm:
            title = lm.group("title").strip() or _title_after(lines, i)
            entries.append({"kind": "checklist", "page": page, "raw": raw, "normalized": normalized, "title": title, "chapter_number": None, "section": current_section.copy() if current_section else {"section_number": None, "section_title": "Checklists for Astrologers"}, "changes": changes})
            continue
        am = APPENDIX.match(normalized)
        if am:
            title = (am.group("title") or "").strip() or normalized
            entries.append({"kind": "appendix", "page": page, "raw": raw, "normalized": normalized, "title": title, "chapter_number": None, "section": {"section_number": None, "section_title": "Appendix"}, "changes": changes})
    last_end_page: int | None = None
    end_marker_pages: dict[int, int] = {}
    for page, raw in lines:
        if page < body_start_page:
            continue
        match = CHAPTER_END.search(raw)
        if not match:
            continue
        num = chapter_end_number(match)
        if num is None:
            continue
        end_marker_pages[num] = page
        chapter_key = (None, num)
        if num > 1 and chapter_key not in seen_chapters and last_end_page is not None:
            entries.append({"kind": "chapter", "page": last_end_page + 1, "raw": raw, "normalized": raw, "title": f"Chapter {num}", "chapter_number": num, "section": None, "changes": [], "evidence_source": ["end_marker"]})
            seen_chapters.add(chapter_key)
        last_end_page = page
    observed_chapters = sorted({
        int(entry["chapter_number"])
        for entry in entries
        if entry["kind"] == "chapter" and isinstance(entry.get("chapter_number"), int)
    })
    for previous, following in zip(observed_chapters, observed_chapters[1:]):
        if following <= previous + 1 or previous not in end_marker_pages:
            continue
        for missing_number in range(previous + 1, following):
            if allowed_chapter_numbers and missing_number not in allowed_chapter_numbers:
                continue
            chapter_key = (None, missing_number)
            if chapter_key in seen_chapters:
                continue
            entries.append({
                "kind": "chapter",
                "page": end_marker_pages[previous] + 1,
                "raw": f"Chapter {missing_number}",
                "normalized": f"CHAPTER {missing_number}",
                "title": f"Chapter {missing_number}",
                "chapter_number": missing_number,
                "section": None,
                "changes": [],
                "evidence_source": ["end_marker_sequence"],
            })
            seen_chapters.add(chapter_key)
    configured_entries, configured_report = _configured_title_entries(lines, body_start_page, configured_sequence)
    existing_keys = {(entry["page"], entry["normalized"]) for entry in entries}
    entries.extend(entry for entry in configured_entries if (entry["page"], entry["normalized"]) not in existing_keys)
    entries.sort(key=lambda entry: entry["page"])
    return entries, {"line_count": len(lines), "body_start_page": body_start_page, "configured_title_sequence": configured_report}


def build_map(entries: list[dict], source_pages: int, body_start_page: int = 6, has_sloka: bool = False) -> tuple[list[dict], dict]:
    map_entries: list[dict] = [{"unit_id": "FRONT", "section_title": "Front Matter", "section_number": None, "chapter_title": "Front Matter", "chapter_number": None, "pdf_pages": [1, max(1, body_start_page - 1)], "evidence_source": ["title"], "chapter_status": "confirmed", "sloka_status": "not_applicable", "raw": "", "normalized": "", "transformations": []}]
    sections = [e for e in entries if e["kind"] == "section"]
    content = [e for e in entries if e["kind"] in {"chapter", "checklist", "appendix"}]
    boundary_pages = sorted({int(entry["page"]) for entry in entries})
    # Add section-only pages before the first child chapter.
    for section in sections:
        next_child = next((e for e in content if e["page"] >= section["page"]), None)
        if next_child is None or next_child["page"] != section["page"]:
            end = (next_child["page"] - 1) if next_child else source_pages
            if end >= section["page"]:
                s = section["section"]
                map_entries.append({"unit_id": f"S{s['section_number'].replace('-', '') if s['section_number'] else 'X'}", "section_title": s["section_title"], "section_number": s["section_number"], "chapter_title": section["title"], "chapter_number": None, "pdf_pages": [section["page"], end], "evidence_source": ["title"], "chapter_status": "confirmed", "sloka_status": "not_applicable", "raw": section["raw"], "normalized": section["normalized"], "transformations": section["changes"]})
    for idx, entry in enumerate(content):
        start = entry["page"]
        next_boundary = next((page for page in boundary_pages if page > start), None)
        end = next_boundary - 1 if next_boundary else source_pages
        section = entry.get("section") or {"section_number": None, "section_title": "unknown"}
        prefix = f"S{section.get('section_number') or 'X'}".replace("-", "")
        if entry.get("chapter_number") is not None:
            suffix = entry["chapter_number"]
        elif entry.get("sequence_index") is not None:
            suffix = f"SEQ{entry['sequence_index']}"
        else:
            suffix = entry["kind"].upper()
        unit_id = f"{prefix}{suffix}"
        title = entry["title"] or "unknown"
        status = "confirmed" if title != "unknown" else "unknown"
        # A skipped numbered heading is an evidence gap, not a guessed title.
        if entry["kind"] == "chapter" and idx:
            previous = content[idx - 1]
            if previous["kind"] == "chapter" and (previous.get("section") or {}).get("section_number") == section.get("section_number"):
                pn, cn = previous.get("chapter_number"), entry.get("chapter_number")
                if isinstance(pn, int) and isinstance(cn, int) and cn > pn + 1:
                    gap_start = previous["page"] + 1
                    gap_end = start - 1
                    if gap_end >= gap_start:
                        missing_num = pn + 1
                        for previous_map in reversed(map_entries):
                            if previous_map.get("chapter_number") == pn and previous_map.get("section_number") == section.get("section_number"):
                                previous_map["pdf_pages"][1] = previous["page"]
                                break
                        map_entries.append({"unit_id": f"{prefix}{missing_num}_UNKNOWN", "section_title": section.get("section_title"), "section_number": section.get("section_number"), "chapter_title": "unknown", "chapter_number": missing_num, "pdf_pages": [gap_start, gap_end], "evidence_source": [], "chapter_status": "unknown", "sloka_status": "not_applicable", "raw": "", "normalized": "", "transformations": []})
        map_entries.append({"unit_id": unit_id, "section_title": section.get("section_title"), "section_number": section.get("section_number"), "chapter_title": title, "chapter_number": entry.get("chapter_number"), "pdf_pages": [start, max(start, end)], "evidence_source": entry.get("evidence_source", ["title"]), "chapter_status": status, "sloka_status": "not_applicable", "raw": entry["raw"], "normalized": entry["normalized"], "transformations": entry["changes"]})
    # Multiple headings starting on one PDF page cannot be ordered from page
    # evidence alone.  Remove the whole same-start group and reserve its
    # common span as one unknown interval; never shift each chapter to page+1.
    starts: dict[int, list[dict]] = {}
    for map_entry in map_entries:
        starts.setdefault(map_entry["pdf_pages"][0], []).append(map_entry)
    shared_groups = {page: group for page, group in starts.items() if len(group) > 1}
    if shared_groups:
        shared_pages = sorted(shared_groups)
        all_starts = sorted(starts)
        revised: list[dict] = []
        for map_entry in map_entries:
            start, end = map_entry["pdf_pages"]
            if start in shared_groups:
                continue
            crossing = [page for page in shared_pages if start < page <= end]
            if crossing:
                end = min(end, min(crossing) - 1)
            if end >= start:
                revised.append({**map_entry, "pdf_pages": [start, end]})
        for page in shared_pages:
            group = shared_groups[page]
            max_end = max(entry["pdf_pages"][1] for entry in group)
            next_start = next((candidate for candidate in all_starts if candidate > page), None)
            shared_end = min(max_end, next_start - 1) if next_start is not None else max_end
            if shared_end >= page:
                revised.append({"unit_id": f"UNKNOWN_SHARED_{page}", "section_title": "unknown", "section_number": None, "chapter_title": "unknown", "chapter_number": None, "pdf_pages": [page, shared_end], "evidence_source": [], "chapter_status": "unknown", "sloka_status": "unknown" if has_sloka else "not_applicable", "raw": "", "normalized": "", "transformations": []})
        map_entries = revised
    map_entries.sort(key=lambda x: x["pdf_pages"][0])
    covered = set()
    for map_entry in map_entries:
        start, end = map_entry["pdf_pages"]
        covered.update(range(start, end + 1))
    missing_pages = [page for page in range(1, source_pages + 1) if page not in covered]
    while missing_pages:
        start = end = missing_pages.pop(0)
        while missing_pages and missing_pages[0] == end + 1:
            end = missing_pages.pop(0)
        map_entries.append({"unit_id": f"UNKNOWN_{start}_{end}", "section_title": "unknown", "section_number": None, "chapter_title": "unknown", "chapter_number": None, "pdf_pages": [start, end], "evidence_source": [], "chapter_status": "unknown", "sloka_status": "unknown" if has_sloka else "not_applicable", "raw": "", "normalized": "", "transformations": []})
    map_entries.sort(key=lambda x: x["pdf_pages"][0])
    unknown_pages = sum(max(0, b - a + 1) for a, b in (e["pdf_pages"] for e in map_entries if e["chapter_status"] == "unknown"))
    body_pages = max(1, source_pages)
    checks = {
        "chapter_number_gaps": [],
        "start_pages_increasing": all(map_entries[i]["pdf_pages"][0] < map_entries[i + 1]["pdf_pages"][0] for i in range(len(map_entries) - 1)),
        "unknown_pages": unknown_pages,
        "body_pages": body_pages,
        "unknown_page_ratio": round(unknown_pages / body_pages, 6),
        "stop": unknown_pages / body_pages > 0.05,
    }
    by_section: dict[str, list[int]] = {}
    for e in map_entries:
        if e["chapter_status"] == "confirmed" and isinstance(e.get("chapter_number"), int):
            by_section.setdefault(str(e.get("section_number")), []).append(e["chapter_number"])
    for section, nums in by_section.items():
        expected = list(range(min(nums), max(nums) + 1))
        if nums != expected:
            checks["chapter_number_gaps"].append({"section": section, "observed": nums, "expected": expected})
    for map_entry in map_entries:
        map_entry["sloka_status"] = "unknown" if has_sloka and (map_entry.get("chapter_number") is not None or map_entry.get("chapter_status") == "unknown") else "not_applicable"
    return map_entries, checks


def assign_entry(chapter_map: list[dict], page: int) -> dict:
    for entry in chapter_map:
        a, b = entry["pdf_pages"]
        if a <= page <= b:
            return entry
    return {"chapter_title": "unknown", "chapter_number": None, "section_title": "unknown", "section_number": None, "chapter_status": "unknown", "sloka_status": "not_applicable", "evidence_source": []}


def build(config: dict, input_dir: Path, output_dir: Path, ab_mode: str = "pure_speed", baseline: Path | None = None) -> dict:
    started = time.perf_counter()
    required_config = ("work_id", "book_title", "source_pdf_sha256", "case_study_heading_paths")
    missing_config = [key for key in required_config if key not in config]
    if missing_config:
        raise ValueError(f"{CONTRACT_VERSION} 配置缺字段: {', '.join(missing_config)}")
    case_study_heading_paths = normalize_case_study_heading_paths(config["case_study_heading_paths"])
    book_md = input_dir / "book.md"
    pages_path = input_dir / "pages.jsonl"
    if not book_md.is_file() or not pages_path.is_file():
        raise FileNotFoundError("输入目录必须先有 book.md 和 pages.jsonl；缺失时由 run_book 调 MinerU")
    pages, inferred_pages = parse_pages(book_md)
    page_rows = [json.loads(x) for x in pages_path.read_text(encoding="utf-8").splitlines() if x.strip()]
    source_pages = max([int(r.get("pdf_page", 0)) for r in page_rows] + [inferred_pages])
    adhyaya_pages = [page for page, lines in pages.items() if any(re.search(r"\bADHYAYA\s+(?:[IVXLCDM]+|\d+)\b", line, re.I) for line in lines)]
    body_start = int(config.get("body_start_page", min(adhyaya_pages) if adhyaya_pages else 6))
    chapter_title_sequence = normalize_chapter_title_sequence(config.get("chapter_title_sequence"))
    entries, scan_meta = scan_chapters(book_md, body_start, chapter_title_sequence)
    sloka_detection = detect_has_sloka(book_md)
    has_sloka = bool(sloka_detection["decision"])
    book_version = str(config.get("book_version") or config.get("pdf_name") or "book.pdf")
    source_group = str(config.get("source_group") or config["work_id"])
    chapter_map, chapter_checks = build_map(entries, source_pages, body_start, has_sloka)
    merge_wrapped_lines = bool(config.get("merge_wrapped_lines", False))
    running_headers = running_header_source_ids(page_rows) if merge_wrapped_lines else set()
    page_furniture_ids = page_furniture_source_ids(page_rows)
    heading_paths, heading_context = heading_paths_for_rows(page_rows, chapter_map, running_headers | page_furniture_ids)
    heading_context["ignored_running_headers"] = len(running_headers)
    heading_context["structural_heading_source_blocks"] = heading_context["heading_blocks"]
    heading_context["page_furniture_source_blocks"] = len(page_furniture_ids)
    heading_context["merge_wrapped_lines"] = merge_wrapped_lines
    output_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(book_md, output_dir / "book.md")
    shutil.copy2(pages_path, output_dir / "pages.jsonl")
    parents, cards, coverage, discarded_blocks = [], [], [], []
    source_texts: list[str] = []
    units = source_units(page_rows, chapter_map, heading_paths, merge_wrapped_lines, body_start, running_headers)
    for unit in units:
            entry = unit["entry"]
            pages_for_unit = unit["pdf_pages"]
            page = pages_for_unit[0]
            source_ids = unit["source_block_ids"]
            source_id = source_ids[0]
            route = unit["route"]
            if route == "discard":
                for block in unit["blocks"]:
                    block_id = str(block["source_block_id"])
                    coverage.append({"source_block_id": block_id, "pdf_page": int(block.get("pdf_page") or page), "status": "discard", "asset_path": None, "parent_id": None, "card_ids": [], "reason": str(block.get("reason") or "discarded")})
                    discarded_blocks.append(block)
                continue
            raw = unit["raw_text"]
            normalized = unit["normalized_text"]
            kind = unit["kind"]
            asset_path = unit["asset_path"]
            parent_id = f"{config['work_id']}_PARENT_{source_id}"
            sloka = first_sloka(raw) if has_sloka and kind == "text" else None
            if not has_sloka or entry.get("chapter_number") is None or kind != "text":
                sloka_status = "not_applicable"
                sloka = None
            else:
                sloka_status = "present" if sloka else "unknown"
            heading_path = unit["heading_path"]
            is_case_study = case_study_for_heading_path(heading_path, case_study_heading_paths)
            page_furniture = len(source_ids) == 1 and source_id in page_furniture_ids
            transformations = list(unit["transformations"])
            if page_furniture:
                transformations.append({"kind": "page_furniture", "rule": "page_edge_repeat_v1"})
            parent = {"parent_id": parent_id, "book_title": config["book_title"], "book_version": book_version, "chapter_number": entry.get("chapter_number"), "chapter_title": entry.get("chapter_title", "unknown"), "chapter_status": entry.get("chapter_status", "unknown"), "sloka": sloka, "sloka_status": sloka_status, "pdf_pages": pages_for_unit, "pdf_page": page, "page_block": source_id, "source_block_ids": source_ids, "kind": kind, "heading_path": heading_path, "raw_text": raw, "normalized_text": normalized, "transformations": transformations, "asset_path": asset_path, "citation": ""}
            parent["citation"] = citation(parent)
            parents.append(parent)
            if asset_path:
                source_asset = input_dir / str(asset_path)
                target = output_dir / str(asset_path)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_asset, target)
            if kind == "image":
                chunks = [("image", "asset", "", False)]
            elif kind == "table":
                rows = [str(row).strip() for row in unit.get("table_rows", []) if str(row).strip()]
                chunks = [("table_row", "derived_for_search", row, True) for row in rows]
            else:
                heading_only = bool(merge_wrapped_lines and len(source_ids) == 1 and source_id not in running_headers and heading_level(unit["blocks"][0]) is not None)
                chunks = [("text", "source", chunk, not page_furniture and not heading_only and not is_high_confidence_mush(chunk)) for chunk in sentence_chunks(normalized)]
                source_texts.extend(chunk for _, _, chunk, indexable in chunks if indexable)
            if not chunks:
                raise ValueError(f"保留块没有可生成卡片的内容: {source_id}")
            card_ids: list[str] = []
            for part_index, (card_kind, text_role, chunk, indexable) in enumerate(chunks, 1):
                card_id = f"{config['work_id']}_CARD_{source_id}_{part_index:02d}"
                card_ids.append(card_id)
                card = {"card_id": card_id, "parent_id": parent_id, "book_title": config["book_title"], "book_version": book_version, "chapter_number": entry.get("chapter_number"), "chapter_title": entry.get("chapter_title", "unknown"), "chapter_status": entry.get("chapter_status", "unknown"), "sloka": sloka, "sloka_status": sloka_status, "pdf_pages": pages_for_unit, "pdf_page": page, "page_block": source_id, "kind": card_kind, "text_role": text_role, "heading_path": heading_path, "is_case_study": is_case_study, "text": chunk, "raw_text": raw, "indexable": indexable, "asset_path": asset_path, "citation": "", "text_sha256": hashlib.sha256(chunk.encode("utf-8")).hexdigest()}
                card["citation"] = citation(card)
                cards.append(card)
            for block in unit["blocks"]:
                coverage.append({"source_block_id": str(block["source_block_id"]), "pdf_page": int(block.get("pdf_page") or page), "status": "asset" if kind == "image" else "retain_text", "asset_path": asset_path, "parent_id": parent_id, "card_ids": card_ids, "reason": None})
    discard_report = discard_misdrop_report(discarded_blocks)
    anomaly_report = text_anomaly_report(source_texts)
    covered_pages = {int(row.get("pdf_page", 0)) for row in page_rows}
    page_coverage = {"actual": len(covered_pages & set(range(1, source_pages + 1))), "expected": source_pages}
    page_coverage["status"] = "pass" if page_coverage["actual"] == source_pages else "fail"
    gate_status = "pass" if page_coverage["status"] == anomaly_report["status"] == discard_report["status"] == "pass" and chapter_checks["unknown_page_ratio"] <= 0.05 else "fail"
    manifest = {"status": gate_status, "contract_version": CONTRACT_VERSION, "work_id": config["work_id"], "book_title": config["book_title"], "book_version": book_version, "source_group": source_group, "case_study_heading_paths": case_study_heading_paths, "has_sloka": has_sloka, "has_sloka_detection": sloka_detection, "source_pages": source_pages, "source_pdf_sha256": config["source_pdf_sha256"], "chapter_map": chapter_map, "chapter_checks": chapter_checks, "chapter_scan": scan_meta, "heading_context": heading_context, "mineru_assembly": config.get("mineru_assembly"), "counts": {"parents": len(parents), "source_cards": len(cards), "coverage_rows": len(coverage), "source_blocks": len(coverage)}, "quality": {"page_coverage": page_coverage, "unknown_pages": chapter_checks["unknown_pages"], "unknown_page_ratio": chapter_checks["unknown_page_ratio"], "text_anomaly": anomaly_report, "discard_misdrop": discard_report}, "ab_validation": {"classification": ab_mode, "status": "pass", "baseline": str(baseline) if baseline else None, "raw_differences": [], "undocumented_raw_changes": 0, "raw_zero_diff": ab_mode == "pure_speed"}, "source_recovery": {"classification": ab_mode, "registered": [], "undocumented_raw_changes": 0}, "elapsed_seconds": round(time.perf_counter() - started, 6)}
    for name, rows in (("parents.jsonl", parents), ("source_cards.jsonl", cards), ("coverage.jsonl", coverage)):
        with (output_dir / name).open("w", encoding="utf-8", newline="\n") as f:
            for row in rows:
                f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    book_config = {key: config[key] for key in ("work_id", "book_title", "author", "body_start_page") if key in config}
    book_config["contract_version"] = CONTRACT_VERSION
    book_config["case_study_heading_paths"] = case_study_heading_paths
    book_config["merge_wrapped_lines"] = merge_wrapped_lines
    if chapter_title_sequence:
        book_config["chapter_title_sequence"] = chapter_title_sequence
    (output_dir / "book_config.json").write_text(json.dumps(book_config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


def package(output_dir: Path, zip_path: Path) -> Path:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((output_dir / "manifest.json").read_text(encoding="utf-8"))
    heading_context = manifest.get("heading_context", {})
    classifications = {
        "structural_heading_source_blocks": int(heading_context.get("structural_heading_source_blocks", 0)),
        "page_furniture_source_blocks": int(heading_context.get("page_furniture_source_blocks", 0)),
    }
    report = write_gate_report(
        load_gate_package(output_dir),
        manifest["work_id"],
        output_dir / "quality_gate_report.json",
        classifications,
        int(manifest["source_pages"]),
    )
    print(json.dumps({"work_id": manifest["work_id"], "quality_gate": report["verdict"]}, ensure_ascii=False))
    if report["verdict"] != "pass":
        raise ValueError("G1-G3、G5、G6 入库质量门未通过，不许打包")
    root_name = manifest["work_id"]
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for path in sorted(output_dir.rglob("*")):
            if path.is_file() and path.resolve() != zip_path.resolve():
                z.write(path, Path(root_name) / path.relative_to(output_dir))
    return zip_path
