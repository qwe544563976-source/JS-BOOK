#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from collections import Counter, defaultdict
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from assemble import _table_rows
from pipeline import (
    CONTRACT_VERSION,
    citation,
    case_study_for_heading_path,
    detect_has_sloka,
    discard_misdrop_report,
    heading_level,
    heading_paths_for_rows,
    is_high_confidence_mush,
    package,
    normalize_case_study_heading_paths,
    sentence_chunks,
    text_anomaly_report,
)
from validate import validate


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def chapter_map_from_parents(parents: list[dict], source_pages: int, has_sloka: bool) -> list[dict]:
    by_page: dict[int, list[tuple[int | None, str]]] = defaultdict(list)
    for parent in parents:
        value = (parent.get("chapter_number"), str(parent.get("chapter_title") or "unknown"))
        for page in parent.get("pdf_pages", []):
            by_page[int(page)].append(value)
    page_values: list[tuple[int | None, str]] = []
    for page in range(1, source_pages + 1):
        page_values.append(Counter(by_page[page]).most_common(1)[0][0])

    result: list[dict] = []
    start = 1
    current = page_values[0]
    for page, value in enumerate(page_values[1:], 2):
        if value == current:
            continue
        result.append(_chapter_entry(len(result) + 1, start, page - 1, current, has_sloka))
        start, current = page, value
    result.append(_chapter_entry(len(result) + 1, start, source_pages, current, has_sloka))
    return result


def _chapter_entry(index: int, start: int, end: int, value: tuple[int | None, str], has_sloka: bool) -> dict:
    number, title = value
    status = "unknown" if title.lower() == "unknown" else "confirmed"
    return {
        "unit_id": f"UNIT_{index:03d}",
        "section_title": "Front Matter" if number is None else title,
        "section_number": None,
        "chapter_title": title,
        "chapter_number": number,
        "pdf_pages": [start, end],
        "evidence_source": ["title"] if status == "confirmed" else [],
        "chapter_status": status,
        "sloka_status": "unknown" if has_sloka and number is not None else "not_applicable",
        "raw": "",
        "normalized": "",
        "transformations": [],
    }


def build(args: argparse.Namespace) -> dict:
    source = args.source.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    config = json.loads(args.config.read_text(encoding="utf-8"))
    if "case_study_heading_paths" not in config:
        raise ValueError("每本书配置必须显式包含 case_study_heading_paths；无案例时填写 []")
    case_study_heading_paths = normalize_case_study_heading_paths(config["case_study_heading_paths"])

    old_parents = read_jsonl(source / "parents.jsonl")
    old_coverage = read_jsonl(source / "coverage.jsonl")
    source_pages = args.pages
    shutil.copy2(source / "book.md", output / "book.md")

    sloka_detection = detect_has_sloka(output / "book.md")
    has_sloka = bool(sloka_detection["decision"])
    chapter_map = chapter_map_from_parents(old_parents, source_pages, has_sloka)

    page_order: dict[int, list[str]] = defaultdict(list)
    coverage_by_source = {row["source_block_id"]: row for row in old_coverage}
    parent_by_source: dict[str, dict] = {}
    first_source: dict[str, str] = {}
    for parent in old_parents:
        sources = [str(value) for value in parent.get("source_block_ids", [])]
        if not sources:
            raise ValueError(f"旧父段缺 source_block_ids: {parent.get('parent_id')}")
        first_source[parent["parent_id"]] = sources[0]
        for source_id in sources:
            if source_id in parent_by_source:
                raise ValueError(f"source_block_id 重复归属: {source_id}")
            parent_by_source[source_id] = parent

    for route in old_coverage:
        page = int(route.get("pdf_page") or str(route["source_block_id"])[1:4])
        source_id = str(route["source_block_id"])
        page_order[page].append(source_id)
    for page in page_order:
        page_order[page].sort(key=lambda value: int(value.rsplit("_B", 1)[1]))

    canonical_pages: list[dict] = []
    parent_blocks: dict[str, dict] = {}
    discarded_blocks: list[dict] = []
    inserted_parents: set[str] = set()
    for page in range(1, source_pages + 1):
        blocks: list[dict] = []
        for source_id in page_order.get(page, []):
            parent = parent_by_source.get(source_id)
            if parent is not None:
                parent_id = parent["parent_id"]
                if parent_id in inserted_parents:
                    continue
                inserted_parents.add(parent_id)
                source_id = first_source[parent_id]
                raw = str(parent.get("raw_text") or "")
                normalized = str(parent.get("normalized_text") or raw)
                kind = str(parent.get("kind") or "text")
                asset_path = parent.get("asset_path")
                block = {
                    "source_block_id": source_id,
                    "pdf_page": int(parent.get("pdf_page") or parent.get("pdf_pages", [page])[0]),
                    "source_type": kind,
                    "bbox": [],
                    "raw_text": raw,
                    "normalized_text": normalized,
                    "transformations": list(parent.get("transformations") or []),
                    "route": "asset" if kind == "image" else "retain_text",
                    "kind": kind,
                    "asset_path": asset_path,
                    "reason": None,
                    "table_rows": _table_rows(raw) if kind == "table" else [],
                }
                blocks.append(block)
                parent_blocks[parent_id] = block
            else:
                route = coverage_by_source.get(source_id, {})
                raw = ""
                block = {
                    "source_block_id": source_id,
                    "pdf_page": page,
                    "source_type": "discarded",
                    "bbox": [],
                    "raw_text": raw,
                    "normalized_text": raw,
                    "transformations": [],
                    "route": "discard",
                    "kind": "text",
                    "asset_path": None,
                    "reason": str(route.get("status") or "discarded"),
                    "table_rows": [],
                }
                blocks.append(block)
                discarded_blocks.append(block)
        canonical_pages.append({"pdf_page": page, "source_block_ids": [row["source_block_id"] for row in blocks], "blocks": blocks})

    if len(inserted_parents) != len(old_parents):
        missing = sorted(set(parent["parent_id"] for parent in old_parents) - inserted_parents)
        raise ValueError(f"父段未进入页序列: {missing[:5]}")

    write_jsonl(output / "pages.jsonl", canonical_pages)
    heading_paths, heading_context = heading_paths_for_rows(canonical_pages, chapter_map)

    parents: list[dict] = []
    cards: list[dict] = []
    coverage: list[dict] = []
    new_parent_by_old: dict[str, dict] = {}
    card_ids_by_old: dict[str, list[str]] = {}
    source_texts: list[str] = []

    for old_parent in old_parents:
        old_parent_id = old_parent["parent_id"]
        source_ids = [str(value) for value in old_parent["source_block_ids"]]
        source_id = source_ids[0]
        block = parent_blocks[old_parent_id]
        raw = block["raw_text"]
        normalized = block["normalized_text"]
        kind = block["kind"]
        chapter_title = str(old_parent.get("chapter_title") or "unknown")
        chapter_number = old_parent.get("chapter_number")
        chapter_status = "unknown" if chapter_title.lower() == "unknown" else "confirmed"
        sloka = str(old_parent["sloka"]) if old_parent.get("sloka") not in (None, "") else None
        if not has_sloka or chapter_number is None or kind != "text":
            sloka = None
            sloka_status = "not_applicable"
        else:
            sloka_status = "present" if sloka else "unknown"
        pdf_pages = [int(value) for value in old_parent.get("pdf_pages", [])]
        page_block = source_id
        parent_id = f"{args.work_id}_PARENT_{source_id}"
        heading_path = heading_paths.get(source_id, [])
        is_case_study = case_study_for_heading_path(heading_path, case_study_heading_paths)
        parent = {
            "parent_id": parent_id,
            "book_title": args.book_title,
            "book_version": args.pdf.name,
            "chapter_number": chapter_number,
            "chapter_title": chapter_title,
            "chapter_status": chapter_status,
            "sloka": sloka,
            "sloka_status": sloka_status,
            "pdf_pages": pdf_pages,
            "pdf_page": pdf_pages[0],
            "page_block": page_block,
            "source_block_ids": source_ids,
            "kind": kind,
            "heading_path": heading_path,
            "raw_text": raw,
            "normalized_text": normalized,
            "transformations": list(old_parent.get("transformations") or []),
            "asset_path": block.get("asset_path"),
            "citation": "",
        }
        parent["citation"] = citation(parent)
        parents.append(parent)
        new_parent_by_old[old_parent_id] = parent

        if parent["asset_path"]:
            source_asset = source / str(parent["asset_path"])
            target_asset = output / str(parent["asset_path"])
            target_asset.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_asset, target_asset)

        if kind == "image":
            chunks = [("image", "asset", "", False)]
        elif kind == "table":
            chunks = [("table_row", "derived_for_search", row, True) for row in block["table_rows"]]
        else:
            is_heading = heading_level(block) is not None
            chunks = [("text", "source", chunk, not is_heading and not is_high_confidence_mush(chunk)) for chunk in sentence_chunks(normalized)]
            source_texts.extend(chunk for _, _, chunk, indexable in chunks if indexable)
        if not chunks:
            raise ValueError(f"父段未生成卡片: {old_parent_id}")

        ids: list[str] = []
        for part_index, (card_kind, text_role, text, indexable) in enumerate(chunks, 1):
            card_id = f"{args.work_id}_CARD_{source_id}_{part_index:02d}"
            ids.append(card_id)
            card = {
                "card_id": card_id,
                "parent_id": parent_id,
                "book_title": args.book_title,
                "book_version": args.pdf.name,
                "chapter_number": chapter_number,
                "chapter_title": chapter_title,
                "chapter_status": chapter_status,
                "sloka": sloka,
                "sloka_status": sloka_status,
                "pdf_pages": pdf_pages,
                "pdf_page": pdf_pages[0],
                "page_block": page_block,
                "kind": card_kind,
                "text_role": text_role,
                "heading_path": heading_path,
                "is_case_study": is_case_study,
                "text": text,
                "raw_text": raw,
                "indexable": indexable,
                "asset_path": parent.get("asset_path"),
                "citation": "",
                "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
            }
            card["citation"] = citation(card)
            cards.append(card)
        card_ids_by_old[old_parent_id] = ids

    for old_route in old_coverage:
        source_id = str(old_route["source_block_id"])
        old_parent = parent_by_source.get(source_id)
        if old_parent is None:
            coverage.append({"source_block_id": source_id, "pdf_page": int(old_route.get("pdf_page") or source_id[1:4]), "status": "discard", "asset_path": None, "parent_id": None, "card_ids": [], "reason": str(old_route.get("status") or "discarded")})
            continue
        parent = new_parent_by_old[old_parent["parent_id"]]
        status = "asset" if parent["kind"] == "image" else "retain_text"
        coverage.append({"source_block_id": source_id, "pdf_page": int(old_route.get("pdf_page") or parent["pdf_page"]), "status": status, "asset_path": parent.get("asset_path"), "parent_id": parent["parent_id"], "card_ids": card_ids_by_old[old_parent["parent_id"]], "reason": None})

    anomaly = text_anomaly_report(source_texts)
    discard = discard_misdrop_report(discarded_blocks)
    unknown_pages = sum(end - start + 1 for start, end in (entry["pdf_pages"] for entry in chapter_map if entry["chapter_status"] == "unknown"))
    unknown_ratio = unknown_pages / source_pages
    status = "pass" if anomaly["status"] == discard["status"] == "pass" and unknown_ratio <= 0.05 else "fail"
    manifest = {
        "status": status,
        "contract_version": CONTRACT_VERSION,
        "work_id": args.work_id,
        "book_title": args.book_title,
        "book_version": args.pdf.name,
        "source_group": args.work_id,
        "case_study_heading_paths": case_study_heading_paths,
        "has_sloka": has_sloka,
        "has_sloka_detection": sloka_detection,
        "source_pages": source_pages,
        "source_pdf_sha256": sha256(args.pdf),
        "chapter_map": chapter_map,
        "chapter_checks": {"unknown_pages": unknown_pages, "body_pages": source_pages, "unknown_page_ratio": round(unknown_ratio, 6), "stop": unknown_ratio > 0.05},
        "heading_context": heading_context,
        "counts": {"parents": len(parents), "source_cards": len(cards), "coverage_rows": len(coverage), "source_blocks": len(coverage)},
        "quality": {
            "page_coverage": {"actual": source_pages, "expected": source_pages, "status": "pass"},
            "unknown_pages": unknown_pages,
            "unknown_page_ratio": round(unknown_ratio, 6),
            "text_anomaly": anomaly,
            "discard_misdrop": discard,
        },
        "ab_validation": {"classification": "quality_correction", "status": "pass", "baseline": str(source), "raw_differences": [], "undocumented_raw_changes": 0, "raw_zero_diff": True},
        "source_recovery": {
            "classification": "quality_correction",
            "registered": [
                {"kind": "contract_v2.1_rebuild_from_clean_blocks", "heading_path": "regenerated_from_page_order"},
                {
                    "kind": "accepted_legacy_discard_routes",
                    "scope": "discard_coverage_only",
                    "raw_text_recovered": False,
                    "note": "沿用 pre-contract 已验收丢弃路由；旧包未保存丢弃块原文，本次未重新扫描其内容",
                },
            ],
            "undocumented_raw_changes": 0,
        },
    }
    write_jsonl(output / "parents.jsonl", parents)
    write_jsonl(output / "source_cards.jsonl", cards)
    write_jsonl(output / "coverage.jsonl", coverage)
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    book_config = {key: config[key] for key in ("work_id", "book_title", "author") if key in config}
    book_config["contract_version"] = CONTRACT_VERSION
    book_config["case_study_heading_paths"] = case_study_heading_paths
    (output / "book_config.json").write_text(json.dumps(book_config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    result = validate(output)
    if result["status"] != "pass":
        return result
    zip_path = package(output, output / f"{args.work_id}.zip")
    return {**result, "zip": str(zip_path)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--pdf", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--work-id", required=True)
    parser.add_argument("--book-title", required=True)
    parser.add_argument("--pages", type=int, required=True)
    args = parser.parse_args()
    result = build(args)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("status") == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
