#!/usr/bin/env python3
"""Convert one MinerU content_list into deterministic page/block inputs."""
from __future__ import annotations

import json
import re
import shutil
from collections import defaultdict
from html.parser import HTMLParser
from pathlib import Path


DEVANAGARI = re.compile(r"[\u0900-\u097f]")
PLANET_WORDS = re.compile(
    r"(?:sun|moon|mars|mercury|merc|venus|ven|jupiter|jup|saturn|sat|rahu|ketu|asc|rasi|lagna|su|mo|ma|me|ju|ve|sa|ra|ke)",
    re.I,
)


class _TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.rows: list[list[str]] = []
        self.row: list[str] | None = None
        self.cell: list[str] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "tr":
            self.row = []
        elif tag in {"td", "th"} and self.row is not None:
            self.cell = []

    def handle_data(self, data: str) -> None:
        if self.cell is not None:
            self.cell.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag in {"td", "th"} and self.cell is not None and self.row is not None:
            self.row.append(" ".join("".join(self.cell).split()))
            self.cell = None
        elif tag == "tr" and self.row is not None:
            self.rows.append(self.row)
            self.row = None


def _table_rows(table_html: str) -> list[str]:
    parser = _TableParser()
    parser.feed(table_html)
    rows = [row for row in parser.rows if any(cell for cell in row)]
    if not rows:
        return []
    header = rows[0]
    if len(rows) == 1:
        return [" | ".join(cell for cell in header if cell)]
    flattened: list[str] = []
    for row in rows[1:]:
        pairs = []
        for index, value in enumerate(row):
            if not value:
                continue
            label = header[index] if index < len(header) and header[index] else f"Column {index + 1}"
            pairs.append(f"{label}: {value}")
        if pairs:
            flattened.append("; ".join(pairs))
    return flattened or [" | ".join(cell for cell in row if cell) for row in rows]


def _looks_like_chart(table_html: str) -> bool:
    plain = re.sub(r"<[^>]+>", " ", table_html)
    letters = re.sub(r"[^A-Za-z]+", "", plain)
    if not letters:
        return False
    remainder = PLANET_WORDS.sub("", letters)
    return len(remainder) / len(letters) <= 0.15


def _discard_reason(source_type: str, text: str) -> str | None:
    if source_type in {"header", "page_number", "footer"}:
        stripped = text.strip()
        words = re.findall(r"\b[\w]+\b", stripped, re.UNICODE)
        english_words = re.findall(r"\b[A-Za-z]+\b", stripped)
        english_ratio = len(english_words) / max(1, len(words))
        if len(stripped) >= 80 and english_ratio >= 0.35:
            # MinerU can mislabel a body paragraph as header/footer. The
            # existing discard hard gate already defines this exact
            # length/English-content criterion, so route it back to text here
            # instead of creating a known false discard.
            return None
        return source_type
    stripped = text.strip()
    if not stripped:
        return "empty"
    compact = re.sub(r"\s+", "", stripped)
    devanagari = len(DEVANAGARI.findall(stripped))
    ascii_letters = len(re.findall(r"[A-Za-z]", stripped))
    digits = len(re.findall(r"\d", stripped))
    if devanagari >= 5 and devanagari / max(1, len(compact)) >= 0.20 and ascii_letters < 5:
        return "non_english_or_unreadable"
    if ascii_letters == 0 and digits == 0:
        return "non_english_or_unreadable"
    return None


def _find_content_list(raw_output: Path, pdf_stem: str) -> Path:
    exact = list(raw_output.rglob(f"{pdf_stem}_content_list.json"))
    candidates = exact or [path for path in raw_output.rglob("*_content_list.json") if not path.name.endswith("_content_list_v2.json")]
    if len(candidates) != 1:
        raise RuntimeError(f"MinerU content_list 数量应为 1，实际 {len(candidates)}: {[str(path) for path in candidates]}")
    return candidates[0]


def assemble_mineru_output(raw_output: Path, input_dir: Path, pdf_stem: str, source_pages: int) -> dict:
    content_path = _find_content_list(raw_output, pdf_stem)
    content = json.loads(content_path.read_text(encoding="utf-8"))
    if not isinstance(content, list):
        raise RuntimeError("MinerU content_list 不是数组")

    assets_dir = input_dir / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    page_blocks: dict[int, list[dict]] = defaultdict(list)
    counters: dict[int, int] = defaultdict(int)

    for item in content:
        page = int(item.get("page_idx", -1)) + 1
        if page < 1 or page > source_pages:
            raise RuntimeError(f"MinerU 页码越界: {page}/{source_pages}")
        block_id = f"P{page:03d}_B{counters[page]:03d}"
        counters[page] += 1
        source_type = str(item.get("type") or "unknown")
        raw_text = str(item.get("text") or "")
        block = {
            "source_block_id": block_id,
            "pdf_page": page,
            "source_type": source_type,
            "bbox": item.get("bbox") or [],
            "raw_text": raw_text,
            "normalized_text": raw_text,
            "transformations": [],
            "route": "retain_text",
            "kind": "text",
            "asset_path": None,
            "reason": None,
            "table_rows": [],
        }

        if source_type in {"image", "table", "equation"}:
            relative = str(item.get("img_path") or "")
            source_asset = content_path.parent / relative if relative else None
            if source_asset is not None and not source_asset.is_file():
                raise RuntimeError(f"MinerU 资产不存在: {source_asset}")
            if source_asset is not None:
                suffix = source_asset.suffix.lower() or ".bin"
                asset_path = f"assets/{block_id}_{source_type}{suffix}"
                shutil.copy2(source_asset, input_dir / asset_path)
                block["asset_path"] = asset_path
            table_html = str(item.get("table_body") or "") if source_type == "table" else ""
            if source_type == "table" and table_html and not _looks_like_chart(table_html):
                block.update(kind="table", raw_text=table_html, normalized_text=table_html, table_rows=_table_rows(table_html))
                if not block["table_rows"]:
                    block.update(route="asset", kind="image") if source_asset is not None else block.update(route="discard", reason="empty_table_without_asset")
            elif source_asset is not None:
                block.update(route="asset", kind="image", raw_text="", normalized_text="")
            elif raw_text.strip():
                block.update(kind="text")
            else:
                block.update(route="discard", reason=f"empty_{source_type}_without_asset")
        else:
            reason = _discard_reason(source_type, raw_text)
            if reason:
                block.update(route="discard", reason=reason)
        page_blocks[page].append(block)

    pages_path = input_dir / "pages.jsonl"
    with pages_path.open("w", encoding="utf-8", newline="\n") as handle:
        for page in range(1, source_pages + 1):
            blocks = page_blocks.get(page, [])
            row = {"pdf_page": page, "source_block_ids": [block["source_block_id"] for block in blocks], "blocks": blocks}
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")

    with (input_dir / "book.md").open("w", encoding="utf-8", newline="\n") as handle:
        for page in range(1, source_pages + 1):
            handle.write(f"<!-- SOURCE_PAGE {page} -->\n\n")
            for block in page_blocks.get(page, []):
                if block["route"] == "retain_text":
                    handle.write(block["normalized_text"].strip() + "\n\n")
                elif block["route"] == "asset":
                    handle.write(f"[ASSET type={block['source_type']} page={page} block={block['source_block_id']} path={block['asset_path']}]\n\n")

    return {
        "content_list": str(content_path.relative_to(raw_output)),
        "source_pages": source_pages,
        "source_blocks": sum(len(blocks) for blocks in page_blocks.values()),
        "retained": sum(block["route"] == "retain_text" for blocks in page_blocks.values() for block in blocks),
        "assets": sum(block["route"] == "asset" for blocks in page_blocks.values() for block in blocks),
        "discarded": sum(block["route"] == "discard" for blocks in page_blocks.values() for block in blocks),
    }
