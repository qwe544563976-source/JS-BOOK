#!/usr/bin/env python3
"""Read-only PDF/environment preflight; standard library only."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def pdf_pages(path: Path) -> int:
    return len(re.findall(rb"/Type\s*/Page(?:\s|/|>)", path.read_bytes()))


def inspect_pdf(path: Path, expected_pages: int | None = None) -> dict:
    if not path.is_file() or path.suffix.lower() != ".pdf":
        raise ValueError(f"PDF 不存在或扩展名错误: {path}")
    data = path.read_bytes()
    if not data.startswith(b"%PDF-"):
        raise ValueError("输入不是 PDF")
    pages = pdf_pages(path)
    if pages <= 0:
        raise ValueError("无法从 PDF 读取页数")
    result = {
        "pdf": str(path.resolve()),
        "sha256": sha256(path),
        "pages": pages,
        "expected_pages": expected_pages,
        "page_count_match": expected_pages is None or expected_pages == pages,
        "bytes": len(data),
        "text_layer_probe": {"pages": [1, max(1, pages // 2), pages], "status": "defer_to_book_md"},
    }
    return result


def probe_cuda(python_executable: str) -> dict:
    code = (
        "import json,torch; print(json.dumps({'available':bool(torch.cuda.is_available()),"
        "'name':torch.cuda.get_device_name(0) if torch.cuda.is_available() else None," 
        "'torch':torch.__version__}))"
    )
    cp = subprocess.run([python_executable, "-c", code], capture_output=True, text=True, check=False, timeout=60)
    lines = [x for x in cp.stdout.splitlines() if x.strip()]
    if cp.returncode or not lines:
        raise RuntimeError(cp.stderr.strip() or "CUDA probe failed")
    info = json.loads(lines[-1])
    if info.get("available") is not True:
        raise RuntimeError("CUDA 不可用，禁止 CPU 回退")
    return info


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", type=Path, required=True)
    ap.add_argument("--expected-pages", type=int)
    ap.add_argument("--output", type=Path)
    ap.add_argument("--mineru-python")
    ap.add_argument("--require-cuda", action="store_true")
    args = ap.parse_args()
    result = inspect_pdf(args.pdf.resolve(), args.expected_pages)
    if args.require_cuda:
        if not args.mineru_python:
            raise SystemExit("--require-cuda 需要 --mineru-python")
        result["cuda"] = probe_cuda(args.mineru_python)
    result["status"] = "pass"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
