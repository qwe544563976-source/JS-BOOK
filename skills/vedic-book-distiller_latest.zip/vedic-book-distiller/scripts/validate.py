#!/usr/bin/env python3
"""Validate the contract_v2.1 source package; legacy packages are rejected."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

try:
    from .pipeline import case_study_config_gaps, case_study_for_heading_path, heading_paths_for_rows, normalize_case_study_heading_paths, page_furniture_source_ids, running_header_source_ids
except ImportError:
    from pipeline import case_study_config_gaps, case_study_for_heading_path, heading_paths_for_rows, normalize_case_study_heading_paths, page_furniture_source_ids, running_header_source_ids


CONTRACT_VERSION = "contract_v2.1"
PARENT_REQUIRED = ("parent_id", "book_title", "book_version", "chapter_number", "chapter_title", "chapter_status", "sloka", "sloka_status", "pdf_pages", "pdf_page", "page_block", "source_block_ids", "kind", "heading_path", "raw_text", "normalized_text", "transformations", "asset_path", "citation")
CARD_REQUIRED = ("card_id", "parent_id", "book_title", "book_version", "chapter_number", "chapter_title", "chapter_status", "sloka", "sloka_status", "pdf_pages", "pdf_page", "page_block", "kind", "text_role", "heading_path", "is_case_study", "text", "raw_text", "indexable", "asset_path", "citation", "text_sha256")
MANIFEST_REQUIRED = ("contract_version", "status", "work_id", "book_title", "book_version", "source_group", "case_study_heading_paths", "has_sloka", "has_sloka_detection", "source_pages", "source_pdf_sha256", "chapter_map", "counts", "quality", "ab_validation", "source_recovery")
COVERAGE_REQUIRED = ("source_block_id", "status", "parent_id", "card_ids", "asset_path", "reason")
CHAPTER_STATUS = {"confirmed", "unknown"}
SLOKA_STATUS = {"present", "not_applicable", "unknown"}
PARENT_KIND = {"text", "table", "image"}
CARD_KIND = {"text", "table_row", "image"}
TEXT_ROLE = {"source", "derived_for_search", "asset"}
COVERAGE_STATUS = {"retain_text", "asset", "discard"}
HEX64 = re.compile(r"^[0-9a-f]{64}$")


def rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def asset_ok(root: Path, value: object) -> bool:
    if not isinstance(value, str) or not value or value.startswith(("/", "\\")) or ".." in Path(value).parts:
        return False
    return (root / value).is_file()


def nonempty_str(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def pages_ok(row: dict) -> bool:
    pages = row.get("pdf_pages")
    return isinstance(pages, list) and bool(pages) and all(isinstance(page, int) and not isinstance(page, bool) and page > 0 for page in pages) and row.get("pdf_page") == pages[0]


def status_ok(row: dict, has_sloka: bool) -> bool:
    if row.get("chapter_status") not in CHAPTER_STATUS or row.get("sloka_status") not in SLOKA_STATUS:
        return False
    if not has_sloka:
        return row.get("sloka") is None and row.get("sloka_status") == "not_applicable"
    if row.get("sloka_status") == "present":
        return isinstance(row.get("sloka"), str) and bool(row["sloka"])
    if row.get("sloka") not in (None, ""):
        return False
    return not has_sloka or row.get("sloka_status") in {"unknown", "not_applicable"}


def citation_ok(row: dict) -> bool:
    citation = row.get("citation")
    pages = row.get("pdf_pages")
    if not isinstance(citation, str) or not isinstance(pages, list) or not pages:
        return False
    if not all(isinstance(page, int) and page > 0 for page in pages):
        return False
    if any(part not in citation for part in (row.get("book_title", ""), row.get("book_version", ""), f"{row.get('chapter_status')}: {row.get('chapter_title')}", "Sloka")):
        return False
    status = row.get("sloka_status")
    label = str(row["sloka"]) if status == "present" else ("N/A" if status == "not_applicable" else "unknown")
    if f"Sloka {label} [{status}]" not in citation:
        return False
    page_label = f"PDF page {pages[0]}" if len(pages) == 1 else f"PDF pages {pages[0]}-{pages[-1]}"
    if page_label not in citation:
        return False
    return status == "present" or f"page_block {row.get('page_block')}" in citation


def validate(root: Path) -> dict:
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    parents, cards, coverage = rows(root / "parents.jsonl"), rows(root / "source_cards.jsonl"), rows(root / "coverage.jsonl")
    page_rows = rows(root / "pages.jsonl")
    failures: list[str] = []
    if any(key not in manifest for key in MANIFEST_REQUIRED):
        failures.append("manifest_fields")
    if manifest.get("contract_version") != CONTRACT_VERSION or manifest.get("status") != "pass" or not isinstance(manifest.get("has_sloka"), bool):
        failures.append("manifest_contract")
    if any(not nonempty_str(manifest.get(key)) for key in ("work_id", "book_title", "book_version", "source_group")):
        failures.append("manifest_types")
    try:
        case_study_heading_paths = normalize_case_study_heading_paths(manifest.get("case_study_heading_paths"))
    except ValueError:
        case_study_heading_paths = []
        failures.append("case_study_heading_paths")
    case_gaps = case_study_config_gaps(cards, case_study_heading_paths)
    if case_gaps:
        failures.append("case_study_config_gaps")
    detection = manifest.get("has_sloka_detection", {})
    if not isinstance(detection, dict) or detection.get("threshold_version") != "sloka_chain_v1" or type(detection.get("decision")) is not bool or detection.get("decision") != manifest.get("has_sloka"):
        failures.append("has_sloka_detection")
    for key in ("hit_count", "eligible_paragraphs", "longest_chain_count", "longest_chain_span", "max_marker", "explicit_sloka_terms", "half_or_range_hits"):
        if type(detection.get(key)) is not int or detection[key] < 0:
            failures.append("has_sloka_detection")
            break
    if not isinstance(manifest.get("source_pages"), int) or isinstance(manifest.get("source_pages"), bool) or manifest["source_pages"] <= 0:
        failures.append("source_pages")
    if not isinstance(manifest.get("source_pdf_sha256"), str) or not HEX64.fullmatch(manifest["source_pdf_sha256"]):
        failures.append("source_pdf_sha256")
    quality = manifest.get("quality", {})
    page = quality.get("page_coverage", {})
    if page.get("status") != "pass" or page.get("actual") != page.get("expected"):
        failures.append("page_coverage")
    if float(quality.get("unknown_page_ratio", 1.0)) > 0.05:
        failures.append("unknown_ratio")
    anomaly = quality.get("text_anomaly", {})
    if anomaly.get("method") != "plain_source_no_vowel_v1" or anomaly.get("status") != "pass" or float(anomaly.get("rate", 1.0)) >= 0.01:
        failures.append("text_anomaly")
    discard = quality.get("discard_misdrop", {})
    discard_rows = [route for route in coverage if route.get("status") == "discard"]
    discard_ok = all((
        discard.get("method") == "plain_text_length_and_english_word_ratio_v1",
        discard.get("length_threshold") == 80,
        discard.get("english_word_ratio_threshold") == 0.35,
        discard.get("scanned_blocks") == len(discard_rows),
        isinstance(discard.get("items"), list),
        discard.get("count") == len(discard.get("items", [])) == 0,
        discard.get("status") == "pass",
    ))
    if not discard_ok:
        failures.append("discard_misdrop")
    if manifest.get("ab_validation", {}).get("undocumented_raw_changes") != 0 or manifest.get("ab_validation", {}).get("status") != "pass":
        failures.append("ab_raw_changes")
    if manifest.get("source_recovery", {}).get("undocumented_raw_changes") != 0:
        failures.append("source_recovery")
    chapter_pages: list[int] = []
    for entry in manifest.get("chapter_map", []):
        if any(key not in entry for key in ("unit_id", "chapter_title", "chapter_number", "pdf_pages", "evidence_source", "chapter_status", "sloka_status", "raw", "normalized", "transformations")):
            failures.append("chapter_map_fields")
            break
        if entry.get("chapter_status") not in CHAPTER_STATUS or entry.get("sloka_status") not in SLOKA_STATUS:
            failures.append("chapter_map_status")
            break
        bounds = entry.get("pdf_pages")
        if not isinstance(bounds, list) or len(bounds) != 2 or not all(isinstance(value, int) and value > 0 for value in bounds) or bounds[0] > bounds[1]:
            failures.append("chapter_map_pages")
            continue
        chapter_pages.extend(range(bounds[0], bounds[1] + 1))
    expected_chapter_pages = list(range(1, manifest.get("source_pages", 0) + 1))
    if sorted(chapter_pages) != expected_chapter_pages:
        failures.append("chapter_map_coverage")
    counts = manifest.get("counts", {})
    if counts.get("parents") != len(parents) or counts.get("source_cards") != len(cards) or counts.get("coverage_rows") != len(coverage) or counts.get("source_blocks") != len(coverage):
        failures.append("counts")

    parent_ids = [parent.get("parent_id") for parent in parents]
    card_ids = [card.get("card_id") for card in cards]
    if len(parent_ids) != len(set(parent_ids)) or len(card_ids) != len(set(card_ids)):
        failures.append("duplicate_ids")
    parent_map = {parent.get("parent_id"): parent for parent in parents}
    card_map = {card.get("card_id"): card for card in cards}
    running_header_ids = running_header_source_ids(page_rows) if manifest.get("heading_context", {}).get("merge_wrapped_lines") else set()
    page_furniture_ids = page_furniture_source_ids(page_rows)
    expected_heading_paths, _ = heading_paths_for_rows(page_rows, manifest.get("chapter_map", []), running_header_ids | page_furniture_ids)
    has_sloka = bool(manifest.get("has_sloka"))
    for parent in parents:
        if any(key not in parent for key in PARENT_REQUIRED):
            failures.append("parent_contract")
            continue
        if not nonempty_str(parent.get("book_title")) or not nonempty_str(parent.get("book_version")) or not nonempty_str(parent.get("chapter_title")) or not nonempty_str(parent.get("page_block")) or not pages_ok(parent) or not isinstance(parent.get("heading_path"), list) or not all(isinstance(value, str) for value in parent.get("heading_path", [])) or not isinstance(parent.get("raw_text"), str) or not isinstance(parent.get("normalized_text"), str) or not isinstance(parent.get("transformations"), list) or not status_ok(parent, has_sloka) or not citation_ok(parent):
            failures.append("parent_contract")
        source_blocks = parent.get("source_block_ids")
        if isinstance(source_blocks, list) and source_blocks and parent.get("heading_path") != expected_heading_paths.get(str(source_blocks[0]), []):
            failures.append("heading_context")
        if isinstance(source_blocks, list) and source_blocks:
            marked_furniture = any(item.get("kind") == "page_furniture" for item in parent.get("transformations", []) if isinstance(item, dict))
            if (str(source_blocks[0]) in page_furniture_ids) != marked_furniture:
                failures.append("page_furniture_marker")
        if parent.get("chapter_number") is not None and (not isinstance(parent.get("chapter_number"), int) or isinstance(parent.get("chapter_number"), bool)):
            failures.append("parent_types")
        if parent.get("asset_path") is not None and not asset_ok(root, parent.get("asset_path")):
            failures.append("parent_asset")
        if parent.get("kind") == "image":
            if not asset_ok(root, parent.get("asset_path")):
                failures.append("parent_asset")
        elif not parent.get("raw_text"):
            failures.append("parent_empty_raw")
    for card in cards:
        if any(key not in card for key in CARD_REQUIRED):
            failures.append("card_contract")
            continue
        if not nonempty_str(card.get("book_title")) or not nonempty_str(card.get("book_version")) or not nonempty_str(card.get("chapter_title")) or not nonempty_str(card.get("page_block")) or not pages_ok(card) or not isinstance(card.get("heading_path"), list) or not all(isinstance(value, str) for value in card.get("heading_path", [])) or type(card.get("is_case_study")) is not bool or not isinstance(card.get("text"), str) or not isinstance(card.get("raw_text"), str) or not isinstance(card.get("indexable"), bool) or card.get("kind") not in CARD_KIND or card.get("text_role") not in TEXT_ROLE or not status_ok(card, has_sloka) or not citation_ok(card):
            failures.append("card_contract")
        elif card["is_case_study"] != case_study_for_heading_path(card["heading_path"], case_study_heading_paths):
            failures.append("case_study_assignment")
        if card.get("page_block") in page_furniture_ids and card.get("indexable") is not False:
            failures.append("page_furniture_indexable")
        if card.get("chapter_number") is not None and (not isinstance(card.get("chapter_number"), int) or isinstance(card.get("chapter_number"), bool)):
            failures.append("card_types")
        if card.get("asset_path") is not None and not asset_ok(root, card.get("asset_path")):
            failures.append("card_asset")
        if card.get("kind") == "image":
            if card.get("text_role") != "asset" or card.get("indexable") is not False or not asset_ok(root, card.get("asset_path")):
                failures.append("card_asset")
        else:
            if not card.get("raw_text") or not card.get("text"):
                failures.append("card_empty_text")
            if card.get("kind") == "table_row" and card.get("text_role") != "derived_for_search":
                failures.append("table_role")
        if len(card.get("text", "")) > 1200:
            failures.append("long_cards")
        if not isinstance(card.get("indexable"), bool) or not isinstance(card.get("text_sha256"), str) or hashlib.sha256(card.get("text", "").encode("utf-8")).hexdigest() != card.get("text_sha256"):
            failures.append("card_hash")
        if card.get("parent_id") not in parent_map:
            failures.append("parent_link")
        elif any(card.get(key) != parent_map[card["parent_id"]].get(key) for key in ("book_title", "book_version", "chapter_number", "chapter_title", "chapter_status", "sloka", "sloka_status", "heading_path")):
            failures.append("parent_metadata")
        if "child_id" in card or "original_text" in card:
            failures.append("legacy_fields")

    source_ids = [row.get("source_block_id") for row in coverage]
    if len(source_ids) != len(set(source_ids)):
        failures.append("unique_source_routes")
    for route in coverage:
        if any(key not in route for key in COVERAGE_REQUIRED):
            failures.append("coverage_fields")
            continue
        status = route.get("status")
        ids = route.get("card_ids")
        if status not in COVERAGE_STATUS or not isinstance(ids, list) or any(card_id not in card_map for card_id in ids):
            failures.append("coverage_contract")
            continue
        if status == "discard":
            if route.get("parent_id") is not None or ids or route.get("asset_path") is not None or not route.get("reason"):
                failures.append("discard_route")
        else:
            parent = parent_map.get(route.get("parent_id"))
            if parent is None or not ids or any(card_map[card_id].get("parent_id") != route.get("parent_id") for card_id in ids):
                failures.append("coverage_parent")
            if status == "retain_text":
                if route.get("reason") is not None:
                    failures.append("retain_route")
                if route.get("asset_path") is not None and (parent.get("kind") != "table" or not asset_ok(root, route.get("asset_path"))):
                    failures.append("retain_route")
            if status == "asset" and (not asset_ok(root, route.get("asset_path")) or parent.get("kind") != "image" or any(card_map[card_id].get("kind") != "image" or card_map[card_id].get("indexable") is not False for card_id in ids)):
                failures.append("asset_route")
    result = {"status": "pass" if not failures else "fail", "failures": sorted(set(failures)), "checks": {"parents": len(parents), "cards": len(cards), "coverage": len(coverage), "unknown_page_ratio": quality.get("unknown_page_ratio"), "contract_version": manifest.get("contract_version"), "case_study_config_gaps": case_gaps}}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("root", type=Path)
    args = ap.parse_args()
    result = validate(args.root.resolve())
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
