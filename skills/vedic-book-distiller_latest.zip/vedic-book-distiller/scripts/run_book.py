#!/usr/bin/env python3
"""Fixed cold-start command: preflight, route, build, validate, package."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from assemble import assemble_mineru_output
from pipeline import build, package
from preflight import inspect_pdf, probe_cuda
from validate import validate


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", type=Path, required=True)
    ap.add_argument("--pdf", type=Path)
    ap.add_argument("--work-id")
    ap.add_argument("--book-title")
    ap.add_argument("--author")
    ap.add_argument("--input-dir", type=Path)
    ap.add_argument("--output", type=Path)
    ap.add_argument("--ab-mode", choices=("pure_speed", "quality_correction"), default="pure_speed")
    ap.add_argument("--baseline", type=Path)
    args = ap.parse_args()
    defaults_path = ROOT.parent / "config" / "defaults.json"
    cfg = json.loads(defaults_path.read_text(encoding="utf-8")) if defaults_path.is_file() else {}
    if args.config:
        cfg.update(json.loads(args.config.read_text(encoding="utf-8")))
    direct = {"work_id": args.work_id, "book_title": args.book_title, "author": args.author}
    cfg.update({key: value for key, value in direct.items() if value is not None})
    if not cfg.get("work_id") or not cfg.get("book_title") or "case_study_heading_paths" not in cfg:
        raise SystemExit("每本书配置必须包含 work_id、book_title 和显式 case_study_heading_paths（无案例也要填 []）")
    pdf = (args.pdf or ((args.input_dir or Path.cwd()) / cfg.get("pdf_name", "book.pdf"))).resolve()
    input_dir = (args.input_dir or pdf.parent).resolve()
    output = (args.output or (input_dir / "distill")).resolve()
    cfg["pdf_name"] = pdf.name
    if pdf.is_file():
        preflight = inspect_pdf(pdf, cfg.get("source_pages"))
        cfg["source_pdf_sha256"] = preflight["sha256"]
        cfg["source_pages"] = preflight["pages"]
        cfg["book_version"] = cfg.get("book_version") or pdf.name
        cfg["source_group"] = cfg.get("source_group") or cfg["work_id"]
        (output.parent / "preflight.json").parent.mkdir(parents=True, exist_ok=True)
        (output.parent / "preflight.json").write_text(json.dumps(preflight, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        if not (input_dir / "book.md").is_file() or not (input_dir / "pages.jsonl").is_file():
            mineru_python = cfg.get("mineru_python")
            if not mineru_python:
                raise SystemExit("缺少 book.md/pages.jsonl，且 config 未提供 mineru_python")
            raw_out = input_dir / "mineru_output"
            raw_out.mkdir(parents=True, exist_ok=True)
            if not list(raw_out.rglob(f"{pdf.stem}_content_list.json")):
                probe_cuda(mineru_python)
                env = os.environ.copy(); env["MINERU_DEVICE_MODE"] = "cuda"
                cmd = [mineru_python, "-c", "from mineru.cli.client import main; main()", "-p", str(pdf), "-o", str(raw_out), "-b", "pipeline", "-m", cfg.get("mineru_method", "ocr")]
                cp = subprocess.run(cmd, env=env, check=False)
                if cp.returncode:
                    raise SystemExit(cp.returncode)
            assembly = assemble_mineru_output(raw_out, input_dir, pdf.stem, cfg["source_pages"])
            cfg["mineru_assembly"] = assembly
    manifest = build(cfg, input_dir, output, args.ab_mode, args.baseline)
    result = validate(output)
    if result["status"] != "pass":
        return 1
    zip_path = package(output, output / f"{cfg['work_id']}.zip")
    print(json.dumps({"status": "pass", "output": str(output), "zip": str(zip_path), "elapsed_seconds": manifest.get("elapsed_seconds")}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
