#!/usr/bin/env python3
"""contract_v2.1 入库质量门 v2；零第三方依赖。"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


GATE_VERSION = "quality_gate_v2"
CONTRACT_VERSION = "contract_v2.1"

COMMON_WORDS = {
    "about", "after", "all", "also", "and", "anger", "are", "as", "asterism",
    "astrology", "at", "before", "birth", "book", "bosom", "by", "chapter",
    "conditions", "career", "century", "chief", "day", "degree", "dasha", "effects", "excessive", "for", "friend",
    "from", "general", "good", "has", "have", "he", "her", "his", "horoscope", "house", "in",
    "is", "it", "jupiter", "lagna", "lord", "lunar", "mars", "mercury", "method", "minister", "month",
    "moon", "nakshatra", "native", "navamsha", "not", "of", "on", "or", "planet", "planets", "points",
    "practical", "quarter", "rahu", "rectification", "rule", "saturn", "series", "she", "should", "sign", "southern", "star",
    "study", "sun", "table", "that", "the", "their", "this", "time", "to", "venus",
    "when", "which", "will", "with", "year", "yoga", "your", "hindu", "suresh",
    "application", "article", "chandra", "mishra", "kalamritam", "kaalamritam", "kaalidas", "modern", "parashari", "saravali", "traditional",
}
PLANET_CODES = {"su", "mo", "ma", "me", "ju", "ve", "sa", "ra", "ke", "sun", "moon", "mars", "mer", "jup", "ven", "sat", "rah", "ket"}
FORMULA_HINT = re.compile(r"(?:\\circ|\\prime|\\cdot|[$°º×÷=]|\d+[oO]\d+|\b(?:column|degree|dasha|rashi|years?|months?|days?)\b|\b(?:rs\.?|usd)\s*\d|\d+/-)", re.I)
WORD = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿ]+")
ASCII_WORD = re.compile(r"[A-Za-z]+")


def _features(text: str) -> dict:
    words = WORD.findall(text)
    ascii_words = ASCII_WORD.findall(text)
    lowers = [word.lower() for word in ascii_words]
    count = len(ascii_words)
    protected = sum(len(word) >= 3 and word in COMMON_WORDS for word in lowers)
    short = sum(len(word) <= 2 for word in ascii_words)
    no_vowel = sum(len(word) >= 2 and not re.search(r"[aeiouy]", word, re.I) for word in ascii_words)
    mixed_case = sum(not (word.islower() or word.isupper() or word.istitle()) for word in ascii_words)
    garble_shape = sum(
        len(word) >= 3 and sum(char.lower() in "afhiqst" for char in word) / len(word) >= 0.75
        for word in ascii_words
    )
    embedded_digits = len(re.findall(r"[A-Za-z]\d|\d[A-Za-z]", text))
    special = sum(text.count(char) for char in "^%>")
    non_ascii = any(ord(char) > 127 and char.isalpha() for char in text)
    planet_codes = sum(word in PLANET_CODES for word in lowers)
    return {
        "words": words,
        "ascii_words": ascii_words,
        "count": count,
        "protected": protected,
        "short_ratio": short / max(count, 1),
        "no_vowel_ratio": no_vowel / max(count, 1),
        "mixed_case_ratio": mixed_case / max(count, 1),
        "garble_ratio": garble_shape / max(count, 1),
        "embedded_digits": embedded_digits,
        "special": special,
        "non_ascii": non_ascii,
        "planet_codes": planet_codes,
        "average_length": sum(map(len, ascii_words)) / max(count, 1),
    }


def _formula_like(text: str, features: dict) -> bool:
    if FORMULA_HINT.search(text):
        return True
    if features["planet_codes"] >= 3:
        return True
    digits = sum(char.isdigit() for char in text)
    return digits >= 4 and digits / max(len(text), 1) >= 0.12


def is_high_confidence_mush(text: str) -> bool:
    """只自动拦明显 OCR 乱码；公式、正常英文和罗马化梵文不自动拦。"""
    text = " ".join(str(text or "").split())
    if not text or len(text) > 260:
        return False
    f = _features(text)
    if f["count"] < 3 or _formula_like(text, f) or f["protected"] >= 2:
        return False
    malformed = max(f["no_vowel_ratio"], f["mixed_case_ratio"], f["garble_ratio"])
    if f["special"] >= 2:
        return True
    if f["embedded_digits"] >= 2 or (f["embedded_digits"] == 1 and f["short_ratio"] >= 0.50 and malformed >= 0.50):
        return True
    if f["non_ascii"] and f["short_ratio"] >= 0.35 and f["protected"] <= 1:
        return True
    if f["short_ratio"] >= 0.45 and malformed >= 0.35:
        return True
    if f["garble_ratio"] >= 0.45 and f["count"] >= 4 and f["protected"] == 0:
        return True
    return f["count"] >= 4 and malformed >= 0.65 and f["average_length"] <= 5.5


def is_review_candidate(text: str) -> bool:
    """疑似项只进报告，不自动修改 indexable。"""
    text = " ".join(str(text or "").split())
    if not text or len(text) > 320 or is_high_confidence_mush(text):
        return False
    f = _features(text)
    if f["count"] < 2 or _formula_like(text, f):
        return False
    return bool(
        f["special"]
        or f["embedded_digits"]
        or (f["protected"] < 2 and f["short_ratio"] >= 0.35)
        or (f["protected"] < 2 and f["garble_ratio"] >= 0.30)
        or (f["protected"] < 2 and f["non_ascii"])
    )


def is_para(text: str) -> bool:
    return 150 <= len(text) <= 700 and sum(char.isalpha() for char in text) / max(len(text), 1) > 0.6 and len(text.split()) >= 18


def _normalized_heading(text: str) -> str:
    return " ".join(str(text or "").split()).casefold()


def _is_structural_heading(card: dict) -> bool:
    target = _normalized_heading(card.get("text", ""))
    return bool(target) and any(_normalized_heading(value) == target for value in card.get("heading_path", []) if isinstance(value, str))


def looks_meaningful(card: dict) -> bool:
    text = str(card.get("text") or "")
    if card.get("_page_furniture") or _is_structural_heading(card) or is_high_confidence_mush(text) or not 20 <= len(text) <= 300:
        return False
    if sum(char.isalpha() for char in text) / max(len(text), 1) < 0.6:
        return False
    return len(re.findall(r"[A-Za-z]{3,}", text)) >= 2


def load_package(path: Path) -> list[dict]:
    file = path / "source_cards.jsonl"
    parents = {
        row["parent_id"]: row
        for row in (json.loads(line) for line in (path / "parents.jsonl").read_text(encoding="utf-8").splitlines() if line.strip())
    }
    cards = [json.loads(line) for line in file.read_text(encoding="utf-8").splitlines() if line.strip()]
    for card in cards:
        parent = parents.get(card.get("parent_id"), {})
        card["_page_furniture"] = any(item.get("kind") == "page_furniture" for item in parent.get("transformations", []) if isinstance(item, dict))
    return cards


def evaluate(cards: list[dict], name: str, source_pages: int | None = None) -> dict:
    indexable = [card for card in cards if card.get("indexable") and card.get("kind") != "image" and card.get("text")]
    dropped = [card for card in cards if not card.get("indexable") and card.get("kind") != "image" and card.get("text")]
    paragraph_cards = [card for card in indexable if is_para(str(card["text"]))]
    mush = [card for card in indexable if is_high_confidence_mush(str(card["text"]))]
    auto_flagged = [card for card in dropped if is_high_confidence_mush(str(card["text"]))]
    review = [card for card in indexable if is_review_candidate(str(card["text"]))]
    meaningful_drops = [card for card in dropped if looks_meaningful(card)]
    n = len(indexable)
    total = len(cards)

    chapters: dict[object, set] = {}
    for card in indexable:
        chapters.setdefault(card.get("chapter_title"), set()).add(card.get("chapter_number"))
    real = sum(
        1 for title in chapters
        if title and not re.match(r"^(Chapter\s*\d+)?$", str(title).strip())
        and sum(char.isalpha() for char in str(title)) / max(len(str(title)), 1) > 0.5
    )
    collisions = [title for title, numbers in chapters.items() if len(numbers) > 1]
    lengths = sorted(len(str(card["text"])) for card in indexable)
    median = lengths[len(lengths) // 2] if lengths else 0
    g1_rate = len(paragraph_cards) / max(n, 1)
    g2_rate = len(mush) / max(n, 1)
    g3_rate = len(meaningful_drops) / max(total, 1)
    page_count = int(source_pages or len({card.get("pdf_page") for card in cards if card.get("pdf_page") is not None}) or 1)
    short_patterns: dict[str, list[dict]] = {}
    for card in indexable:
        text = " ".join(str(card.get("text") or "").split())
        if len(text) <= 80:
            short_patterns.setdefault(re.sub(r"\d+", "#", text), []).append(card)
    furniture_patterns = {
        pattern: matched
        for pattern, matched in short_patterns.items()
        if len(matched) >= 5
        and len(matched) >= page_count * 0.10
        and not pattern.rstrip().endswith(":")
        and len(re.findall(r"[A-Za-z]{2,}", pattern)) >= 2
    }
    furniture_cards = [card for matched in furniture_patterns.values() for card in matched]
    g5_rate = len(furniture_cards) / max(n, 1)
    g6_rate = n / max(total, 1)

    def brief(card: dict) -> dict:
        return {
            "card_id": card.get("card_id"),
            "text": str(card.get("text") or "")[:300],
            "citation": card.get("citation"),
            "heading_path": card.get("heading_path", []),
        }

    return {
        "gate_version": GATE_VERSION,
        "contract_version": CONTRACT_VERSION,
        "work_id": name,
        "counts": {"source_cards": total, "indexable_text_cards": n, "nonindexable_text_cards": len(dropped)},
        "G1": {"status": "pass" if g1_rate >= 0.20 else "fail", "paragraph_cards": len(paragraph_cards), "rate": round(g1_rate, 6), "minimum": 0.20},
        "G2": {"status": "pass" if g2_rate <= 0.03 else "fail", "remaining_high_confidence": len(mush), "rate": round(g2_rate, 6), "maximum": 0.03, "auto_flagged": [brief(card) for card in auto_flagged], "review_candidates": [brief(card) for card in review]},
        "G3": {"status": "pass" if g3_rate <= 0.02 else "fail", "suspected_misdrops": [brief(card) for card in meaningful_drops], "count": len(meaningful_drops), "rate": round(g3_rate, 6), "maximum": 0.02},
        "G5": {
            "status": "pass" if g5_rate <= 0.03 else "fail",
            "suspected_furniture_cards": len(furniture_cards),
            "pattern_count": len(furniture_patterns),
            "rate": round(g5_rate, 6),
            "maximum": 0.03,
            "source_pages": page_count,
            "patterns": [
                {"normalized_text": pattern, "count": len(matched), "samples": [brief(card) for card in matched[:3]]}
                for pattern, matched in sorted(furniture_patterns.items(), key=lambda item: (-len(item[1]), item[0]))
            ],
        },
        "G6": {"status": "pass" if g6_rate >= 0.85 else "fail", "indexable_text_cards": n, "source_cards": total, "rate": round(g6_rate, 6), "minimum": 0.85},
        "warnings": {
            "W1": {"status": "pass" if real / max(len(chapters), 1) >= 0.50 else "warn", "real_chapter_rate": round(real / max(len(chapters), 1), 6)},
            "W2": {"status": "pass" if not collisions else "warn", "collisions": [str(value) for value in collisions]},
            "W3": {"status": "pass" if median >= 60 else "warn", "median_card_length": median},
        },
        "verdict": "pass" if n and g1_rate >= 0.20 and g2_rate <= 0.03 and g3_rate <= 0.02 and g5_rate <= 0.03 and g6_rate >= 0.85 else "fail",
    }


def render(report: dict) -> str:
    counts, g1, g2, g3, g5, g6, warnings = report["counts"], report["G1"], report["G2"], report["G3"], report["G5"], report["G6"], report["warnings"]
    lines = [
        f"=== 质量门 · {report['work_id']} ===",
        f"可检索文本卡 {counts['indexable_text_cards']} | 不可检索文本卡 {counts['nonindexable_text_cards']} | 源卡总数 {counts['source_cards']}",
        f"[{'过' if g1['status']=='pass' else '拦'}] G1 段落卡占比 {g1['rate']*100:.1f}% (要求≥20%)",
        f"[{'过' if g2['status']=='pass' else '拦'}] G2 可检索高置信乱码率 {g2['rate']*100:.1f}% (要求≤3%)；已隔离 {len(g2['auto_flagged'])}，疑似待复核 {len(g2['review_candidates'])}",
        f"[{'过' if g3['status']=='pass' else '拦'}] G3 疑似误丢 {g3['count']} 条，{g3['rate']*100:.1f}% (要求≤2%)",
        f"[{'过' if g5['status']=='pass' else '拦'}] G5 版面家具率 {g5['rate']*100:.1f}% ({g5['suspected_furniture_cards']} 张，{g5['pattern_count']} 种模式，要求≤3%)",
        f"[{'过' if g6['status']=='pass' else '拦'}] G6 索引率 {g6['rate']*100:.1f}% ({g6['indexable_text_cards']}/{g6['source_cards']}，要求≥85%)",
        f"[{'过' if warnings['W1']['status']=='pass' else '警'}] W1 真章名率 {warnings['W1']['real_chapter_rate']*100:.0f}%",
        f"[{'过' if warnings['W2']['status']=='pass' else '警'}] W2 章名撞车 {len(warnings['W2']['collisions'])} 个",
        f"[{'过' if warnings['W3']['status']=='pass' else '警'}] W3 中位卡长 {warnings['W3']['median_card_length']} 字符",
        f"—— 判定:{'✅ 可交付' if report['verdict']=='pass' else '❌ 不许交付'}",
    ]
    return "\n".join(lines) + "\n"


def write_report(cards: list[dict], name: str, output: Path, classifications: dict | None = None, source_pages: int | None = None) -> dict:
    report = evaluate(cards, name, source_pages)
    if classifications is not None:
        report["classifications"] = classifications
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", nargs="?")
    parser.add_argument("work_id", nargs="?")
    parser.add_argument("--sqlite", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if not args.path:
        parser.print_help()
        return 0
    if args.sqlite:
        raise SystemExit("quality_gate_v2 的 G6 必须读取完整 source_cards.jsonl；请对成品书包目录运行，不能用只含可检索卡的 SQLite 代替")
    else:
        root = Path(args.path)
        cards = load_package(root)
        name = args.work_id or root.name
        manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
        heading_context = manifest.get("heading_context", {})
        classifications = {
            "structural_heading_source_blocks": int(heading_context.get("structural_heading_source_blocks", 0)),
            "page_furniture_source_blocks": int(heading_context.get("page_furniture_source_blocks", 0)),
        }
    report = evaluate(cards, name, int(manifest["source_pages"]))
    if not args.sqlite:
        report["classifications"] = classifications
    print(render(report), end="")
    if args.output:
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return 0 if report["verdict"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
